"""Audio for a story reel.

usage:
  audio.py prep  IN OUT [--tempo 1.0] [--pause 0.0] [--maxpause 0] [--gap N=SECONDS ...]
        Clean up a voice-over: mono 48 kHz WAV, trims silence at both ends, optional slow-down
        (--tempo 0.88 = 12% slower, pitch kept) and wider pauses (--pause 0.25 adds 0.25 s to every
        pause longer than 0.25 s). --maxpause 0.8 caps every pause at 0.8 s in the output, so a TTS
        "..." breath never turns into a dead gap. Use on TTS takes; leave a human recording as is
        (except --maxpause, if the user finds a gap too long). prep prints every gap it found, numbered,
        with its position and length in OUT; --gap 2=0.7 sets gap 2 to 0.7 s (repeatable). Use it when the
        user says one particular pause is too long or too short.
        Also writes OUT.timemap.json so word times from the original take can be moved onto OUT.
  audio.py music OUT SECONDS [--mood warm|night|bright] [--seed N]
        A soft, original background bed made from scratch (drone + slow plucked pentatonic notes +
        room reverb). Use when there is no music track; any royalty-free track the user gives is better.
  audio.py mix PROJECT [--music FILE] [--music-db -21] [--sfx FILE@TIME[@DB]] ... [--lufs -15]
        VO (vo/vo.wav at STORY.voOffset) + music bed + sound effects -> audio/mix.wav, exactly STORY.dur long,
        loudness-normalised. Music fades in/out and ducks under the voice.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ffmpeg, run, decode_mono, write_wav, story_setting

SR = 48000


def opt(rest, k, d):
    return rest[rest.index(k) + 1] if k in rest else d


def frames_db(x, hop):
    import numpy as np
    n = len(x) // hop
    e = np.sqrt((x[: n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12)
    return 20 * np.log10(e)


def prep(src, dst, tempo, pause, maxpause=0.0, setgap=None):
    setgap = setgap or {}
    import numpy as np, tempfile
    x = decode_mono(src, SR)
    hop = SR // 100
    db = frames_db(x, hop)
    thr = max(np.percentile(db, 95) - 32, -60)
    on = np.where(db > thr)[0]
    if len(on) == 0:
        sys.exit("silent file")
    a = max(0, on[0] * hop - int(.05 * SR)); b = min(len(x), (on[-1] + 1) * hop + int(.25 * SR))
    x = x[a:b]
    edits = []  # [position in the trimmed source (s), seconds added (+) or removed (-)]
    # gaps = runs of weak frames (silence plus breath tails, thr+12 dB) inside the speech; edits happen
    # only in a gap's truly silent core (thr), so no syllable or breath is ever cut
    db = frames_db(x, hop); quiet = db <= thr; weak = db <= thr + 12
    gaps, i, n = [], 0, len(db)
    while i < n:
        if not weak[i]:
            i += 1; continue
        j = i
        while j < n and weak[j]:
            j += 1
        if (j - i) >= 25 and i > 0 and j < n:
            si, sl, k = i, 0, i  # longest silent run inside the gap
            while k < j:
                if quiet[k]:
                    m = k
                    while m < j and quiet[m]:
                        m += 1
                    if m - k > sl: si, sl = k, m - k
                    k = m
                else:
                    k += 1
            gaps.append((i, j, si, sl))
        i = j
    if pause > 0 or maxpause > 0 or setgap:
        out, last = [], 0
        for g, (i, j, si, sl) in enumerate(gaps, 1):
            L = (j - i) * hop / SR
            d = pause if sl >= 25 else 0.0
            if maxpause > 0:
                d = min(L + d, maxpause * tempo) - L  # cap is in output time
            if g in setgap:
                d = setgap[g] * tempo - L
            mid = (si + sl // 2) * hop
            if d > 1e-3 and sl >= 10:
                edits.append([mid / SR, d])
                out.append(x[last:mid]); out.append(np.zeros(int(d * SR), np.float32)); last = mid
            elif d < -1e-3 and sl * hop / SR > .08:
                cut = int(min(-d, sl * hop / SR - .06) * SR); c0 = mid - cut // 2
                edits.append([c0 / SR, -cut / SR])
                out.append(x[last:c0]); last = c0 + cut
        out.append(x[last:]); x = np.concatenate(out)
    tmp = tempfile.mktemp(suffix=".wav"); write_wav(tmp, x, SR)
    af = [f"atempo={tempo}"] if abs(tempo - 1) > 1e-3 else []
    af += ["highpass=f=70", "loudnorm=I=-16:TP=-1.5:LRA=11"]
    run([ffmpeg(), "-y", "-v", "error", "-i", tmp, "-af", ",".join(af), "-ar", str(SR), "-ac", "1", dst])
    os.remove(tmp)
    import json
    json.dump({"trim": a / SR, "edits": edits, "tempo": tempo}, open(dst + ".timemap.json", "w"))
    d = len(decode_mono(dst, SR)) / SR
    print(f"wrote {dst}  ({d:.2f} s)  + {os.path.basename(dst)}.timemap.json (pass it to align.py --map when the")
    print("speech-to-text was made on the ORIGINAL take)")
    sh = lambda t: t + sum(dd for m, dd in edits if m < t)
    print("gaps (number: where in OUT, length in OUT) -- change one with --gap N=SECONDS:")
    print("  " + "  ".join(f"{g}: {sh(i * hop / SR) / tempo:.2f}s {(sh(j * hop / SR) - sh(i * hop / SR)) / tempo:.2f}s"
                         for g, (i, j, si, sl) in enumerate(gaps, 1)))


def music(dst, dur, mood="warm", seed=7):
    """Original procedural bed: a tanpura-like drone, a soft pad and sparse plucked notes."""
    import numpy as np
    rng = np.random.default_rng(seed)
    n = int(dur * SR); t = np.arange(n) / SR; y = np.zeros(n)
    root = {"warm": 146.83, "night": 130.81, "bright": 164.81}.get(mood, 146.83)  # D3 / C3 / E3
    ratios = [1, 9 / 8, 5 / 4, 3 / 2, 5 / 3, 2, 9 / 4, 5 / 2]  # pentatonic (S R G P D) over two octaves

    def pluck(f, t0, dec, amp, bright=1.0, slide=0.0):
        i0 = int(t0 * SR); L = min(n - i0, int(dec * 5 * SR))
        if L <= 0:
            return
        tt = np.arange(L) / SR
        ff = f * (1 + slide * np.exp(-tt * 18))  # small slide into the note
        ph = 2 * np.pi * np.cumsum(ff) / SR
        s = np.zeros(L)
        for h in range(1, 9):
            s += np.sin(ph * h + rng.random() * 6.28) * (1 / h ** (1.6 - .5 * bright)) * np.exp(-tt * h * .5 / dec)
        env = np.minimum(1, tt / .004) * np.exp(-tt / dec)
        y[i0:i0 + L] += amp * s * env

    # drone: P, S', S', S (low) plucked in a slow cycle, like a tanpura
    cyc = [root * 3 / 4, root, root, root / 2]; k = 0; tt0 = 0.0
    while tt0 < dur:
        pluck(cyc[k % 4], tt0, 3.2, .16, bright=1.4); k += 1; tt0 += 1.15 + rng.random() * .1
    # pad: soft fifths with slow movement
    for f, a in [(root / 2, .05), (root * 3 / 4, .03), (root, .035)]:
        y += a * np.sin(2 * np.pi * f * t + .3 * np.sin(2 * np.pi * .07 * t)) * (0.7 + .3 * np.sin(2 * np.pi * .05 * t + f))
    # melody: sparse notes, mostly stepwise
    gap = {"warm": (1.4, 2.6), "night": (2.2, 3.6), "bright": (0.9, 1.8)}.get(mood, (1.4, 2.6))
    tm, idx = 1.2, 3
    while tm < dur - 1.5:
        idx = int(np.clip(idx + rng.choice([-2, -1, -1, 0, 1, 1, 2]), 0, len(ratios) - 1))
        pluck(root * 2 * ratios[idx], tm, 1.3, .11, bright=1.0, slide=-.02 if rng.random() < .4 else 0)
        if rng.random() < .25:
            pluck(root * 2 * ratios[max(0, idx - 1)], tm + .28, 1.0, .07)
        tm += rng.uniform(*gap)
    # room reverb (exponential noise tail), stereo
    L = int(2.4 * SR); tail = rng.standard_normal((2, L)) * np.exp(-np.arange(L) / SR / .55)
    tail[:, : int(.02 * SR)] = 0
    nfft = 1 << int(np.ceil(np.log2(n + L)))
    Y = np.fft.rfft(y, nfft)
    wet = np.stack([np.fft.irfft(Y * np.fft.rfft(tail[c], nfft), nfft)[:n] for c in range(2)], 1)
    wet /= np.abs(wet).max() + 1e-9
    dry = y / (np.abs(y).max() + 1e-9)
    st = .55 * np.stack([dry, dry], 1) + .45 * wet
    fade = np.minimum(1, np.minimum(t / 1.5, (dur - t) / 2.5)).clip(0, 1)[:, None]
    st = st * fade
    st /= np.abs(st).max() + 1e-9
    write_wav(dst, st * .8, SR)
    print(f"wrote {dst}  ({dur:.1f} s, mood {mood})")


def mix(P, rest):
    dur = story_setting(P, "dur"); off = story_setting(P, "voOffset", 0.3)
    if not dur:
        sys.exit("story.js needs STORY.dur")
    vo = opt(rest, "--vo", os.path.join(P, "vo", "vo.wav"))
    mus = opt(rest, "--music", None)
    mdb = float(opt(rest, "--music-db", -21)); lufs = float(opt(rest, "--lufs", -15))
    sfx = [rest[i + 1] for i, a in enumerate(rest) if a == "--sfx"]
    ins = ["-i", vo]; fl = [f"[0:a]aformat=sample_rates={SR}:channel_layouts=stereo,adelay={int(off*1000)}|{int(off*1000)},apad,atrim=0:{dur}[v]"]
    labels = ["[v]"]; k = 1
    if mus:
        ins += ["-stream_loop", "-1", "-i", mus]
        fl.append(f"[{k}:a]aformat=sample_rates={SR}:channel_layouts=stereo,atrim=0:{dur},volume={mdb}dB,afade=t=in:d=1.2,afade=t=out:st={max(0,dur-2.5)}:d=2.5[m0]")
        fl.append("[v]asplit[v1][vk]"); labels = ["[v1]"]
        fl.append("[m0][vk]sidechaincompress=threshold=0.05:ratio=3:attack=200:release=900[m]")
        labels.append("[m]"); k += 1
    for s in sfx:
        parts = s.split("@"); f = parts[0]; at = float(parts[1]); db = float(parts[2]) if len(parts) > 2 else -8
        ins += ["-i", f]
        fl.append(f"[{k}:a]aformat=sample_rates={SR}:channel_layouts=stereo,volume={db}dB,adelay={int(at*1000)}|{int(at*1000)},apad,atrim=0:{dur}[s{k}]")
        labels.append(f"[s{k}]"); k += 1
    fl.append("".join(labels) + f"amix=inputs={len(labels)}:normalize=0:duration=first,loudnorm=I={lufs}:TP=-1.5:LRA=11,atrim=0:{dur}[out]")
    os.makedirs(os.path.join(P, "audio"), exist_ok=True)
    out = os.path.join(P, "audio", "mix.wav")
    run([ffmpeg(), "-y", "-v", "error", *ins, "-filter_complex", ";".join(fl), "-map", "[out]", "-ar", str(SR), "-ac", "2", out])
    print(f"wrote {out}  ({dur:.2f} s, VO at {off:.2f} s, target {lufs} LUFS)")


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    if a[0] == "prep":
        prep(a[1], a[2], float(opt(a, "--tempo", 1.0)), float(opt(a, "--pause", 0.0)), float(opt(a, "--maxpause", 0.0)),
             {int(k): float(v) for k, v in (g.split("=") for g in [a[i + 1] for i, x in enumerate(a) if x == "--gap"])})
    elif a[0] == "music":
        music(a[1], float(a[2]), opt(a, "--mood", "warm"), int(opt(a, "--seed", 7)))
    elif a[0] == "mix":
        mix(os.path.abspath(a[1]), a[2:])
    else:
        sys.exit(__doc__)
