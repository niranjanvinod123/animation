"""Check and install everything the skill needs, then render one test frame.

usage: python3 setup.py            (from anywhere; safe to run again)

Installs, only if missing: the Python packages playwright, numpy, pillow (and imageio-ffmpeg when there is
no ffmpeg), and a Chromium for Playwright (skipped when Google Chrome is installed).
Finishes with a self-test: renders one frame of the bundled example to a temporary folder.
"""
import importlib, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__)); SKILL = os.path.dirname(HERE)
ok = lambda m: print("  ok  ", m)
todo = lambda m: print("  ..  ", m)


def pip(*pkgs):
    cmd = [sys.executable, "-m", "pip", "install", "-q", *pkgs]
    r = subprocess.run(cmd)
    if r.returncode != 0:  # some managed Pythons need --user or --break-system-packages
        r = subprocess.run(cmd + ["--user"])
    if r.returncode != 0:
        subprocess.run(cmd + ["--break-system-packages"], check=True)


def main():
    print("Python", sys.version.split()[0], "at", sys.executable)
    if sys.version_info < (3, 8):
        sys.exit("Python 3.8 or newer is needed")
    for mod, pkg in (("playwright", "playwright"), ("numpy", "numpy"), ("PIL", "pillow")):
        try:
            importlib.import_module(mod); ok(pkg)
        except ImportError:
            todo("installing " + pkg); pip(pkg); ok(pkg)
    if shutil.which("ffmpeg"):
        ok("ffmpeg " + shutil.which("ffmpeg"))
    else:
        try:
            import imageio_ffmpeg  # noqa
        except ImportError:
            todo("no system ffmpeg, installing imageio-ffmpeg"); pip("imageio-ffmpeg")
        ok("ffmpeg (imageio-ffmpeg)")
    # browser
    sys.path.insert(0, HERE)
    from playwright.sync_api import sync_playwright
    from common import launch_browser
    try:
        with sync_playwright() as p:
            launch_browser(p).close()
        ok("Chromium")
    except BaseException:
        todo("installing Chromium for Playwright (about 150 MB)")
        r = subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"])
        if r.returncode != 0 and sys.platform.startswith("linux"):
            subprocess.run([sys.executable, "-m", "playwright", "install", "--with-deps", "chromium"])
        with sync_playwright() as p:
            launch_browser(p).close()
        ok("Chromium")
    # self-test
    tmp = tempfile.mkdtemp(prefix="story-reel-test-")
    proj = os.path.join(tmp, "example"); shutil.copytree(os.path.join(SKILL, "examples", "pothichoru"), proj)
    r = subprocess.run([sys.executable, os.path.join(HERE, "render.py"), proj, "stills", "3.5"], capture_output=True, text=True)
    still = os.path.join(proj, "work", "stills", "s_003.50.jpg")
    if r.returncode == 0 and os.path.exists(still) and "PAGE ERRORS" not in r.stdout:
        ok("test frame rendered: " + still)
        print("\nAll set. The skill is ready to make videos.")
    else:
        print(r.stdout[-1500:], r.stderr[-1500:])
        sys.exit("Self-test failed; see the messages above.")


if __name__ == "__main__":
    main()
