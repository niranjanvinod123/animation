"""Shared helpers: find ffmpeg, launch a headless Chromium, read STORY settings from story.js."""
import os, re, shutil, subprocess, sys

SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENGINE = os.path.join(SKILL, "engine")


def ffmpeg():
    """Path to an ffmpeg binary: PATH first, then the imageio-ffmpeg wheel (pip install imageio-ffmpeg)."""
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        pass
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "imageio-ffmpeg"], check=True)
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        sys.exit("ffmpeg not found. Install it (brew install ffmpeg / apt-get install ffmpeg) or: pip install imageio-ffmpeg")


def run(cmd, quiet=True):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("command failed: " + " ".join(cmd[:6]) + " ...\n" + r.stderr[-2000:])
    return r


def decode_mono(path, sr=48000):
    """Decode any audio file to a float32 mono numpy array."""
    import numpy as np
    r = subprocess.run([ffmpeg(), "-v", "error", "-i", path, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"], capture_output=True)
    if r.returncode != 0:
        sys.exit("could not decode " + path + "\n" + r.stderr.decode()[-800:])
    return np.frombuffer(r.stdout, dtype=np.float32).copy()


def write_wav(path, x, sr=48000):
    import numpy as np, wave
    x = np.clip(x, -1, 1)
    d = (x * 32767).astype("<i2")
    if d.ndim == 2:
        ch = d.shape[1]
    else:
        ch = 1
    with wave.open(path, "wb") as w:
        w.setnchannels(ch); w.setsampwidth(2); w.setframerate(sr); w.writeframes(d.tobytes())


def story_setting(project, key, default=None):
    """Read a number like `dur:20.5` or `voOffset:0.3` out of story.js (first match)."""
    s = open(os.path.join(project, "story.js"), encoding="utf-8").read()
    m = re.search(r"\b" + key + r"\s*:\s*([0-9.]+)", s)
    return float(m.group(1)) if m else default


def launch_browser(p):
    """Launch headless Chromium with Playwright. Tries the bundled browser, then installed Chrome,
    then CHROME_PATH / common install paths."""
    args = ["--force-color-profile=srgb", "--disable-gpu-vsync", "--no-sandbox"]
    errs = []
    try:
        return p.chromium.launch(args=args)
    except Exception as e:
        errs.append(str(e).splitlines()[0])
    try:
        return p.chromium.launch(channel="chrome", args=args)
    except Exception as e:
        errs.append(str(e).splitlines()[0])
    cands = [os.environ.get("CHROME_PATH", ""),
             "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
             "/Applications/Chromium.app/Contents/MacOS/Chromium",
             "/usr/bin/chromium", "/usr/bin/chromium-browser", "/usr/bin/google-chrome",
             r"C:\Program Files\Google\Chrome\Application\chrome.exe",
             r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"]
    for c in cands:
        if c and os.path.exists(c):
            return p.chromium.launch(executable_path=c, args=args)
    raise SystemExit("No Chromium found. Run:  python -m playwright install chromium   (or set CHROME_PATH)\n" + "\n".join(errs))
