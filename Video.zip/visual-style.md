# The look

Soft, warm, hand-made 2D. Think of a picture book lit like a film: simple rounded shapes, smooth gradient shading,
real light (sun shafts, lamp glow, dusk blue), floating dust, gentle depth of field, film grain, a camera that never
stops drifting. Nothing is flat-grey or static; nothing has a hard black outline.

## Drawing rules (for anything you add)

- **Shapes:** rounded paths and ellipses, filled with the engine's gradients (`url(#skinA)`, `url(#woodG)`,
  `url(#steelG)`, `url(#leafG)` …) or your own `<linearGradient>`/`<radialGradient>` defined inline with `uid()` ids.
- **Shading, not outlines:** a darker shade on one side (`url(#shadeX)` or a 6–12% black shape), a soft highlight on
  the other (white at 6–25%). Only skin gets a thin, low-opacity warm edge (`outlined()` in rig.js) so it separates
  from backgrounds.
- **Contact shadows:** every object that sits on something gets a blurred dark ellipse under it (`filter="url(#b8)"`,
  opacity .2–.35). This is what makes things feel placed.
- **Depth:** background layers blurred (`<g filter="url(#b4)">` … `b8`), foreground elements big and very blurred
  (`b14`/`b22`), subject sharp.
- **Real proportions.** Arms end at mid-thigh; hands are about the size of the face; a bicycle wheel reaches an
  adult's hip; doors are taller than people. Check against the characters already in the frame.
- **Clothes cover bodies.** Sleeves are drawn over the upper arm and anchored to the torso's shoulder corner;
  arms come out of the sleeve, never through the cloth. Use `sleeve()` and the layering order of `man()`/`woman()`.
- **Culturally exact props:** steel tumblers, banana leaves, mundu with kasavu border, tiled roofs, coconut palms,
  kerosene lamps, Malayalam lettering on boards and calendars. Specific beats generic.
- **Deterministic:** randomness only through `mul(seed)`; motion only from `t`/`T`. Never `Math.random()` or `Date`.

## Light and colour (every shot gets a light pass)

At the end of every shot add, in this order: light sources (`godRays`, `glow`), particles (`dust`, `steam`, `rain`),
then one or two `grade()` layers. Pick one mood per scene and keep it across its shots:

| Mood | Light | Grade |
|---|---|---|
| Morning / kitchen / courtyard | sun shafts from a window, warm dust | `grade('#ffe2b0','#6a3a1c',.3)` |
| Midday / outdoor / summer | bright sky, short shadows, few particles | `grade('#fff1c8','#3a5a40',.22)` |
| Rain / monsoon | grey-green, rain streaks, ripples, no sun | `grade('#cfe0e6','#2c3a38',.3)` |
| Dusk / evening | lamp or window glow, blue room | `grade('#3a4a8a','#1a0f0a',.38,'multiply')` + `grade('#ffb760','#2a1a40',.22)` |
| Night / power cut | one warm lamp, deep blue, big glow | `grade('#1d2a5a','#05060c',.5,'multiply')` + `glow()` |
| Memory / flashback | softer, warmer, slightly faded | add `grade('#ffe7c4','#ffe7c4',.18,'screen')` |

Skin must stand out from what is behind it: if the ground or wall is a similar brown, change the set colour, not
the skin.

## Shot grammar

- **Shot length** ~2–3.5 s, one per phrase/sentence; cut on the narration's pauses (word times in `timing.js`;
  shot times are in video time = word time + `voOffset`).
- **Mix shot types** across the reel:
  1. Wide set (establish place and time of day).
  2. Medium front view of a character, behind a counter/table or from the waist up (the engine's strength).
  3. **Hands close-up** — hands doing the key action (tying, hiding, holding, pushing). Hands carry the emotion.
  4. **Top-down** object or table shot (plates, a letter, a calendar, a box being opened).
  5. **Text insert** with readable words (`noteCard`, `calendarPage`, a shop board, a phone message).
- **Camera:** always moving — slow push-in (`z` 1.0 → 1.15 over the shot) or drift (`cx`/`cy` by 20–60 px). Put
  background on depth .6–.85, subject on 1, foreground on 1.15–1.4 so it parallaxes.
- **Transitions:** 0.4 s cross-dissolve by default. Avoid dissolving between two different faces in the same
  position (ghosting); offset them or use `cut:true`.
- **Hook:** the first shot is already in motion and already emotional: a close-up of the key object or action.
- **Time jumps:** day → dusk on the same set, the same character with `grey:1`/`glasses:1`, a calendar page flip.
- **End card:** the last ~2.5 s return to the opening image, slightly darker at the top for the title.

## Characters

Front-facing puppets: blinks (`blinkAt`), small head tilts, eyes that look (`lookX/lookY`), gentle smiles, slow arm
moves. Keep motion small and continuous (a 2–6 px sway from `Math.sin(t*…)`). Avoid side-view walking and lip-sync.
For an older version of a person use the same colours with `grey`, `glasses`, a slightly lower head.

## Captions

Only the language being spoken (no translation line unless the user asks for one). Bottom third (`--capTop`,
default 1470 px), centred, max two lines, words light up as they are spoken while the rest
of the line waits at 30% opacity. Text inside quotes is italic. Keep faces, hands and the key prop above y≈1400 so
captions never cover them. The title card sits at `--titleTop` (≈430–560 px); keep that area calm in the last shot.

## QA checklist (look at every still)

1. Sleeves and clothes cover shoulders and upper arms; no arm passes through cloth; hands are attached to wrists.
2. Arms and hands have human length and size; nothing is rubbery or doll-stiff without reason.
3. Skin contrasts with the background and the ground.
4. Movement direction makes sense (walking toward camera = ground moves toward camera and things grow), and screen
   direction stays the same across cuts.
5. Every key prop is fully inside the frame (not cropped at the edges) in every shot where it matters.
6. Captions are readable, inside the frame, not over a face or the key action; the title card has calm space.
7. Every shot has light (rays/glow), particles or grade, and a moving camera — no flat, static frames.
8. The same character looks the same in every shot.
9. Text in the scene is spelled correctly and readable.
10. Nothing on screen that the user did not ask for: no logos, brands or watermarks.
