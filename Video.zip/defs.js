window.ENGINE_DEFS=`  <filter id="b2" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2"/></filter>
  <filter id="b4" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="4"/></filter>
  <filter id="b8" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="8"/></filter>
  <filter id="b14" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="14"/></filter>
  <filter id="b22" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="22"/></filter>
  <filter id="grain" x="0" y="0" width="100%" height="100%">
    <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="1" result="n"/>
    <feColorMatrix type="saturate" values="0"/>
  </filter>
  <linearGradient id="skinA" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#b98159"/><stop offset=".55" stop-color="#9c6643"/><stop offset="1" stop-color="#7e4f33"/></linearGradient>
  <linearGradient id="skinC" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#c58d63"/><stop offset=".55" stop-color="#a8714b"/><stop offset="1" stop-color="#8a5839"/></linearGradient>
  <radialGradient id="cheek" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#c0705a" stop-opacity=".35"/><stop offset="1" stop-color="#c0705a" stop-opacity="0"/></radialGradient>
  <linearGradient id="hairG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3a2c24"/><stop offset=".5" stop-color="#1c1410"/><stop offset="1" stop-color="#120c09"/></linearGradient>
  <linearGradient id="mundu" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#d9d3c6"/><stop offset=".45" stop-color="#f4f0e6"/><stop offset="1" stop-color="#cfc8b9"/></linearGradient>
  <linearGradient id="canopyF" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#0f0f12"/><stop offset=".35" stop-color="#2c2c31"/><stop offset=".6" stop-color="#1a1a1e"/><stop offset="1" stop-color="#09090b"/></linearGradient>
  <radialGradient id="canopyTop" cx=".38" cy=".34" r=".75"><stop offset="0" stop-color="#4a4a52"/><stop offset=".35" stop-color="#232327"/><stop offset="1" stop-color="#0b0b0d"/></radialGradient>
  <radialGradient id="puddle" cx=".45" cy=".4" r=".6"><stop offset="0" stop-color="#c9d1cd"/><stop offset=".75" stop-color="#9eaaa6"/><stop offset="1" stop-color="#6f6a5e"/></radialGradient>
  <linearGradient id="skyG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8f9b98"/><stop offset="1" stop-color="#c9cfc8"/></linearGradient>
  <linearGradient id="pathG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8f877c"/><stop offset=".35" stop-color="#6a6158"/><stop offset="1" stop-color="#4f4740"/></linearGradient>
  <linearGradient id="grassG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7d917a"/><stop offset=".3" stop-color="#557548"/><stop offset="1" stop-color="#3e5f33"/></linearGradient>
  <linearGradient id="haze" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c9d0cb" stop-opacity=".0"/><stop offset=".33" stop-color="#c9d0cb" stop-opacity=".55"/><stop offset=".48" stop-color="#c9d0cb" stop-opacity="0"/></linearGradient>
  <linearGradient id="bagG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#7a2b22"/><stop offset=".5" stop-color="#a23d2c"/><stop offset="1" stop-color="#6b241c"/></linearGradient>
  <linearGradient id="shadeX" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000" stop-opacity=".18"/><stop offset=".22" stop-color="#000" stop-opacity="0"/><stop offset=".72" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".24"/></linearGradient>
  <linearGradient id="woodG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6b3f22"/><stop offset=".5" stop-color="#9a6436"/><stop offset="1" stop-color="#5a331b"/></linearGradient>
  <linearGradient id="shadeX" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000" stop-opacity=".18"/><stop offset=".22" stop-color="#000" stop-opacity="0"/><stop offset=".72" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".24"/></linearGradient>
  <linearGradient id="skinW" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#b57c56"/><stop offset=".55" stop-color="#97603f"/><stop offset="1" stop-color="#7a4a30"/></linearGradient>
  <radialGradient id="leafG" cx=".45" cy=".4" r=".7"><stop offset="0" stop-color="#5fa04a"/><stop offset=".7" stop-color="#3f7f34"/><stop offset="1" stop-color="#2d6127"/></radialGradient>
  <radialGradient id="riceG" cx=".42" cy=".38" r=".65"><stop offset="0" stop-color="#fffdf6"/><stop offset=".75" stop-color="#efe9dc"/><stop offset="1" stop-color="#d8cfbe"/></radialGradient>
  <radialGradient id="eggG" cx=".38" cy=".32" r=".7"><stop offset="0" stop-color="#ffffff"/><stop offset=".7" stop-color="#f1ede4"/><stop offset="1" stop-color="#d6cfc2"/></radialGradient>
  <linearGradient id="woodTop" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8a5a36"/><stop offset=".5" stop-color="#77492a"/><stop offset="1" stop-color="#5e3820"/></linearGradient>
  <radialGradient id="glowWarm" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffd58a" stop-opacity=".9"/><stop offset=".4" stop-color="#ffb04a" stop-opacity=".35"/><stop offset="1" stop-color="#ff9a30" stop-opacity="0"/></radialGradient>
  <linearGradient id="rayG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff3d6" stop-opacity=".55"/><stop offset="1" stop-color="#fff3d6" stop-opacity="0"/></linearGradient>
  <linearGradient id="steelG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8e949b"/><stop offset=".3" stop-color="#e3e7ea"/><stop offset=".55" stop-color="#b9bfc5"/><stop offset="1" stop-color="#6f757c"/></linearGradient>
`;
