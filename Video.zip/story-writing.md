# Writing the story

These reels work because they are **small true-feeling family stories about one ordinary object**, told quietly,
with a turn at the end that the viewer feels before it is said. Write like that.

## The shape (use it for anything 20 s or longer)

1. **Title = one everyday object or moment** everyone from the place owns or remembers: a lunch packet, a pair of
   glasses, a coin pot, a bicycle, an umbrella, a power cut, a school bag, a radio, the first salary.
   The object appears in the first shot and again in the last shot.
2. **Open on a ritual.** "Every morning…", "Every night…", "Whenever it rained…", "For thirty years…". The viewer
   recognises it at once.
3. **A quiet sacrifice by someone who loves the narrator** (Amma, Achan, Ammoomma, Appooppan, an elder sibling, a
   teacher). Never explain it. Show it through one specific detail and let the viewer work it out.
4. **A small twist or secret** the narrator only understood later (optional in very short pieces).
5. **A time jump:** "Years later…", "Yesterday…", "Today…".
6. **Role reversal:** the narrator now does the thing for the elder, or for their own child.
7. **A payoff line of 1–5 words**, usually dialogue, shown in quotes (it renders in italics): "Can you see now?",
   "Hold on tight, Achan.", "Both."
8. **End card:** the opening image again, with the title.

Short versions keep 1, 2, 3, 5/6 and 7. Never add a moral at the end — the payoff line does the work.

## Sentences

- Short declarative sentences. One idea per sentence. First person ("I", "my Amma") or close third person.
- One precise sensory detail beats three adjectives: the sound of bangles, the smell of the rain, the warm rice,
  the cracked lens.
- Use the family words people really use (Amma, Achan, Ammoomma, Uppa, Umma, Chettan, Chechi…).
- Write `...` where you want a breath inside a sentence; the TTS pauses there and the caption shows a comma.
- Put each sentence on its own line in `vo/script.txt`. The video's captions show only these words. Write an
  English translation for the user in the chat so they can follow the script; put it in `vo/english.txt`
  (line for line, natural English, family words like Amma and Achan untranslated) only if the user wants English
  subtitles on the video.

## Length

The narrator is slow and warm: about **11–13 Malayalam characters per second** (roughly 2 words/s) with pauses
between sentences.

| Video | Narration | Malayalam words | Script lines |
|---|---|---|---|
| 15 s | ~12 s | 15–20 | 3 |
| 20 s | ~17 s | 22–30 | 4 |
| 30 s | ~27 s | 35–45 | 5–6 |
| 60 s | ~55 s | 75–95 | 9–12 |
| 90 s | ~85 s | 115–140 | 14–18 |

## Title card text

`title: {ml, en, meaning}` — the Malayalam title (the object), its English transliteration and a 2–4 word English
meaning ("the packed lunch", "the spectacles").

## Show the user before spending credits

When you write the script yourself, show the Malayalam lines, the English lines, the title and a one-line shot idea
per sentence. Wait for an OK (or edits) before generating the voice.

## Example (15 s)

```
എല്ലാ ദിവസവും രാവിലെ... അമ്മ എനിക്ക് പൊതിച്ചോറ് കെട്ടിത്തരും.
ചോറിനടിയിൽ... എന്നും ഒരു മുട്ട ഒളിപ്പിച്ചിട്ടുണ്ടാകും.
അമ്മയുടെ പൊതിയിൽ... ഒരിക്കലും മുട്ട ഉണ്ടായിരുന്നില്ല.
```
```
Every morning, Amma packed my lunch in a banana leaf.
Under the rice, there was always an egg, hidden.
Amma's own packet never had one.
```
Title: പൊതിച്ചോറ് / Pothichoru / the packed lunch. Built in `examples/pothichoru/`.
