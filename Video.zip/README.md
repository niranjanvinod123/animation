# Story Reel Animator: install and use

This skill makes short animated story videos (9:16, 1080x1920) in a warm, soft 2D style. Claude draws every frame
in code, so no image or video generator is involved. You give it a voice-over, or a story idea plus the ElevenLabs
connector, and it delivers a finished MP4 with captions, music and a title card.

---

## 1. Add the skill to Claude

You need a paid Claude plan (Pro, Max, Team or Enterprise). Skills run Claude's own code.

### Claude app (claude.ai on the web, or the desktop app's chat)

1. Open **Settings → Capabilities**.
2. Turn on **Code execution and file creation**.
3. Turn on **network access for code** if you see it (it may be called package installs or allowed domains).
   The first run downloads a few tools: Playwright with its Chromium browser, and numpy.
4. Under **Skills**, click **Upload skill** and choose `story-reel-animator.zip`. Upload the zip as it is; don't
   unzip it first.
5. Make sure the skill's toggle is on.

> The exact menu names can shift a little between app versions. Look for "Capabilities" and "Skills".

### Claude Code, or the Code tab in the desktop app (recommended for long videos)

This route runs on your own computer, which renders faster and keeps the full-quality files on your disk.

```bash
mkdir -p ~/.claude/skills
unzip story-reel-animator.zip -d ~/.claude/skills/
```

Then start a new Claude Code session. On Windows, unzip it into `%USERPROFILE%\.claude\skills\` instead.

---

## 2. Install what the skill needs (one time)

In a new chat, say:

> **Set up the story-reel-animator skill.**

Claude runs `tools/setup.py`, which:

- checks Python
- installs `playwright`, `numpy` and `pillow` if they are missing
- installs a Chromium browser, unless Google Chrome is already installed
- finds ffmpeg, or installs a bundled copy if there isn't one
- renders one test frame to confirm everything works

You can also run it yourself:

```bash
python3 ~/.claude/skills/story-reel-animator/tools/setup.py
```

If you're on a Mac and Python is missing, install it from python.org. If you'd rather use a system ffmpeg, run
`brew install ffmpeg` on Mac or `sudo apt-get install ffmpeg` on Linux. It's optional.

---

## 3. Connect ElevenLabs (optional, for making the voice)

Skip this if you'll always upload your own recording.

- **Connector:** go to **Settings → Connectors**, add **ElevenLabs** and sign in. Claude can then pick a voice,
  generate the narration and transcribe it for the captions.
- **API key (Claude Code):** set `ELEVENLABS_API_KEY` in your environment. The skill's `tts_api.py` and
  `stt_api.py` scripts use it.

With neither of these, you upload your own audio and paste the script. Claude works out the caption timing from
the audio.

---

## 4. Use it

Upload a voice-over and ask:

> Make a story reel from this voice-over. Title: കണ്ണട.

Or give an idea and let Claude write the story and make the voice:

> Make a 20-second story reel about my grandmother's cracked spectacles. Write the Malayalam script, show it to me
> first, then use the ElevenLabs connector for the voice.

What happens next:

1. Claude shows you the script (with an English translation in the chat, so you can follow it). Nothing is spent on voice credits until you approve.
2. It makes or prepares the voice-over and times the captions.
3. It draws the scenes, checks still frames and fixes problems before the full render.
4. It mixes the music and delivers `out/<Title>_v1.mp4`.

Afterwards you can ask for changes, such as "slower camera", "make Achan older", "add English subtitles too", "shorten the pause after the first line" or
"put my handle @yourname on the end card".

### Tips

- Stories of 15 to 30 seconds render in a few minutes. A 90-second story takes longer, especially inside the
  Claude app's sandbox.
- Simple, specific family stories about one everyday object work best.
- To change the look, ask for it: night, rain, a school, a bus stop or a festival.
