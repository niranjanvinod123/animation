---
name: story-reel-animator
description: Make a finished 9:16 animated story reel (1080x1920 MP4) in a warm, hand-made 2D vector style — soft-shaded characters, cosy Kerala-style sets, light rays and dust, slow camera moves, cross-dissolves, word-by-word captions in the language being spoken and a title end card — drawn entirely in code (SVG), no image or video generators. Input is a voice-over: the user uploads an audio file, or the voice-over is made with the ElevenLabs connector (or API) from a script Claude writes. Use whenever the user wants an animated story, a narrated short, a "kadha" reel, a nostalgic family story video, a 2D animation for a voice-over, or mentions this skill — even if they only give a topic or a memory to turn into a story.
---

# Story reel animator

You turn **a voice-over** into **a finished 1080x1920, 30 fps MP4**: a short, emotional story told in soft 2D
vector animation that is drawn by code. Everything is in this folder: a deterministic SVG engine (characters, sets,
props, lighting, captions, end card), the render/alignment/audio tools and fonts.

**Precedence:** what the user says in the chat wins over this file. Where the user is silent, follow this file.

## Files to read

| When | Read |
|---|---|
| Always, before planning shots | `references/visual-style.md` (the look, shot grammar, captions, QA checklist) |
| Always, before writing `story.js` | `references/engine-api.md` (every function and its parameters) and `examples/pothichoru/story.js` |
| When you write or polish the script | `references/story-writing.md` |
| When you make or prepare the audio | `references/audio.md` |

## Setup (first use on a machine or sandbox, or when the user asks to set the skill up)

`SKILL` below means this skill's folder. Run the setup script first — it installs only what is missing
(`playwright`, `numpy`, `pillow`, a Chromium unless Chrome exists, an ffmpeg fallback) and renders a test frame:

```bash
python3 SKILL/tools/setup.py
```

If it fails on a download, the sandbox probably has no network access for packages: tell the user to enable it
(Settings → Capabilities, network access for code execution) or to use Claude Code on their computer, as described
in `README.md`. If the user asks how to install or use the skill, answer from `README.md`. Never install anything
system-wide with sudo without asking. Make the project in the user's working folder (or the outputs folder):

```bash
python3 SKILL/tools/new_project.py <name>      # -> <name>/{index.html, story.js, vo/, audio/, out/}
```

## Workflow

### 1. Get the voice-over and the exact words

Three routes — pick the one that fits what the user gave you. Details and tool calls: `references/audio.md`.

- **A. The user uploaded an audio file.** Copy it to `vo/raw.<ext>`. You need the exact words: transcribe it with
  the ElevenLabs connector (`creative_transcribe_audio`, word timestamps) or `tools/stt_api.py` if they have an API
  key, or ask the user to paste the script. Write `vo/script.txt` (one sentence per line, correct spelling) and
  `vo/stt.json` (the word list). Do **not** change the speed of a human recording unless asked.
- **B. Make it with the ElevenLabs connector.** Write the script first (`references/story-writing.md`), show it to the
  user with its English translation, and wait for an OK before spending credits. Then generate ONE take of the whole
  script, download it, transcribe it, and check every line was spoken.
- **C. The user has an ElevenLabs API key** (env `ELEVENLABS_API_KEY`): `tools/tts_api.py` and `tools/stt_api.py`.

Then:

```bash
python3 SKILL/tools/audio.py prep vo/raw.mp3 vo/vo.wav [--tempo 0.88 --pause 0.25]   # tempo/pause only for TTS
python3 SKILL/tools/align.py <project> [--map vo/vo.wav.timemap.json]                 # -> timing.js
```

`prep` lists every pause it found, numbered, with its length. A TTS `...` breath can come out as a long dead
gap: if the user says a pause is too long or too short, re-run `prep` with the same options plus `--gap N=SECONDS`
for that pause (about 0.6–0.8 s inside a sentence), re-run `align.py`, and move the shot times after it by the
same amount. `--maxpause 0.8` caps every pause at once.

`align.py` turns script + timings into `timing.js` (words, caption chunks) and prints the suggested video length.
Captions show only the language being spoken. Write `vo/english.txt` (one English line per script line) only when
the user asks for English subtitles too; then set `captions:'both'`. Without an
`stt.json` it estimates the timings from the audio — fine, but check the captions on the stills.

### 2. Plan the shots

Read the script and `timing.js`, then write a shot list: one shot per phrase or sentence, ~2–3.5 s each, cut on
the narration's pauses. Mix the shot types (wide set, medium character, hands close-up, top-down object, text insert)
and decide the mood/light of each shot. The first shot is the hook: the strongest image of the story, up close,
moving from frame one. The last shot calls back to the opening image with the title card. Write the plan as a
comment block at the top of `story.js`.

### 3. Build `story.js`

Each shot is a function `s1(T,t)` returning SVG; `window.STORY` lists them with their start/end times, plus `dur`,
`voOffset`, `captions` and `title`. Reuse the engine's characters, sets and props; draw anything the story needs that
the engine does not have (a bicycle, a bus, a classroom, a fishing boat …) as new functions in `story.js`, following
the drawing rules in `references/visual-style.md` (gradients and soft shadows, no hard outlines, real proportions,
props fully in frame). Keep one design per character across shots (same colours, hair, clothes).

### 4. Look at stills, fix, repeat

```bash
python3 SKILL/tools/render.py <project> stills 0.5 2 4 6 8 ...   # 1–2 stills per shot -> work/sheet.jpg
```

Open `work/sheet.jpg` (and single stills at full size where detail matters) and go through the QA checklist in
`references/visual-style.md` honestly: anatomy (sleeves cover the shoulders, hands attached, arms not too long),
contrast (skin vs. background), direction of movement, props in frame, captions readable and clear of faces, every
shot moving. Fix and re-render stills until a frame-by-frame look finds nothing wrong. This step is where quality
comes from; do at least two rounds.

### 5. Music and mix

Use the user's music if they gave one. Otherwise make an original bed with `audio.py music`, or a richer one with
the full ElevenLabs connector / API if available. A soft, short sound effect on one or two key moments helps
(connector `creative_generate_in_flow` with `node_type:"sfx"`); keep them sparse.

```bash
python3 SKILL/tools/audio.py music audio/bed.wav <dur> --mood warm        # warm | night | bright
python3 SKILL/tools/audio.py mix <project> --music audio/bed.wav [--sfx audio/x.mp3@4.2@-10]
```

### 6. Render and deliver

```bash
python3 SKILL/tools/render.py <project> clean          # after any change to story.js since the last frames render
python3 SKILL/tools/render.py <project> video --name <Title>_v1
```

Watch a few seconds around each cut (extract frames with ffmpeg if you cannot play video) before delivering.
Deliver `out/<Title>_v1.mp4`, a short note (story, shots, voice, anything not verified), and an optional
post caption: the Malayalam title | English title, one quoted line from the story, a "tag someone who…" line and
3–5 hashtags.

## Defaults (when the user does not say)

- 9:16, 1080x1920, 30 fps; length = voice-over + ~0.3 s lead-in + ~2.5 s end card.
- Captions only in the language being spoken (`captions:'ml'` — the narration's own words, whatever the language).
  No English or other translation line unless the user asks for one; then `'both'` (narration on top, translation
  under it) or `'en'` (translation only).
- End card: Malayalam title, English transliteration, English meaning. `title.handle` is empty unless the user gives
  their handle or name — never put any brand, logo or watermark on the video that the user did not ask for.
- Voice (route B): a slow, warm, mature narrator voice that speaks the story's language well.
- Never cut together sentences from different TTS takes; if a take skips or garbles words, generate the whole script
  again.

## Troubleshooting

- `No Chromium found` → `python3 -m playwright install chromium`, or set `CHROME_PATH` to a Chrome/Chromium binary.
- Blank or black frames → a JavaScript error in `story.js`; `render.py stills` prints `PAGE ERRORS`. Fix the first one.
- Captions early/late → edit the times in `timing.js` by hand, or get a real transcript (`stt.json`) and re-run align.
- Malayalam renders as boxes → the page did not load `engine/engine.css`; keep `index.html` from the template.
- Rendering is slow → `--workers N` (one Chromium per worker). ~1–3 frames/s per worker is normal.
