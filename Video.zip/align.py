"""Word timings for the captions -> PROJECT/timing.js (window.TIMING = {words, phrases, english}).

usage: align.py PROJECT [--audio vo/vo.wav] [--stt vo/stt.json] [--map vo/vo.wav.timemap.json] [--max-words 4]

--map: use when stt.json was made on the original take and vo.wav came out of `audio.py prep`
       (slowed / wider pauses); it moves the STT times onto vo.wav.

Inputs in PROJECT/vo/:
  script.txt   the narration, ONE SENTENCE PER LINE, spelled the way it should appear on screen
  english.txt  optional, only when the user wants English subtitles too: one line per script line
  vo.wav       the voice-over (any format ffmpeg reads; pass --audio for another name)
  stt.json     optional speech-to-text with word timestamps (ElevenLabs Scribe / connector output,
               or any list of {text,start,end}). Recommended: it makes the captions exact.

Without stt.json the timings are estimated from the audio itself: the pauses split the audio into
speech segments and each segment gets the run of words whose length fits it best.
That is close (usually within ~0.2 s) but check the stills.
Times are in VO time (seconds from the start of the voice-over file); STORY.voOffset shifts them.
"""
import json, os, re, sys, difflib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import decode_mono

ZW = re.compile(r"[‌‍]")


def norm(w):
    return ZW.sub("", re.sub(r"[^\wഀ-ൿ]", "", w)).lower()


def load_script(p):
    lines = [l.strip() for l in open(p, encoding="utf-8").read().splitlines() if l.strip() and not l.lstrip().startswith("#")]
    out = []
    for li, l in enumerate(lines):
        l = re.sub(r"\s*(\.\.\.|…)\s*", ", ", l).replace(",,", ",")
        for w in l.split():
            if norm(w):
                out.append([w, li])
            elif out and w in ",.?!":
                out[-1][0] += w
    for w in out:
        w[0] = re.sub(r",([.?!])$", r"\1", w[0])
    return out, len(lines)


def load_stt(p):
    d = json.load(open(p, encoding="utf-8"))
    if isinstance(d, dict):
        if "transcripts" in d:
            d = d["transcripts"][0]
        d = d.get("words", d)
    ws = []
    for w in d:
        if w.get("type", "word") != "word":
            continue
        t = w.get("text") or w.get("word") or ""
        s = w.get("start", w.get("start_time"))
        if norm(t) and s is not None:
            ws.append((t, float(s), float(w.get("end", w.get("end_time", s)))))
    return ws


def speech_segments(x, sr=16000):
    import numpy as np
    hop = sr // 100
    n = len(x) // hop
    e = np.sqrt((x[: n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12)
    db = 20 * np.log10(e)
    thr = max(np.percentile(db, 95) - 30, -55)
    on = db > thr
    # fill tiny gaps (<0.15 s) and drop blips (<0.06 s)
    segs = []
    i = 0
    while i < n:
        if on[i]:
            j = i
            while j < n and on[j]:
                j += 1
            segs.append([i, j]); i = j
        else:
            i += 1
    merged = []
    for s in segs:
        if merged and s[0] - merged[-1][1] < 15:
            merged[-1][1] = s[1]
        else:
            merged.append(s)
    return [(a / 100, b / 100) for a, b in merged if b - a >= 6]


def estimate(words, nlines, audio):
    """Split the audio into speech segments at pauses, then find the best way to hand each segment a
    run of consecutive words (segment length ~ word length, breaks preferred at punctuation)."""
    import math
    segs = speech_segments(decode_mono(audio, 16000))
    if not segs:
        sys.exit("no speech found in " + audio)
    N = len(words)
    while len(segs) > N:  # more segments than words: close the shortest pause
        i = min(range(len(segs) - 1), key=lambda i: segs[i + 1][0] - segs[i][1])
        segs[i:i + 2] = [(segs[i][0], segs[i + 1][1])]
    K = len(segs)
    wt = [len(norm(w)) + 2 for w, _ in words]
    pre = [0]
    for x in wt:
        pre.append(pre[-1] + x)
    rate = sum(b - a for a, b in segs) / pre[-1]
    brk = [bool(re.search(r"[,.?!\"”]$", w)) or (i + 1 < N and words[i + 1][1] != li) for i, (w, li) in enumerate(words)]
    INF = float("inf")
    best = [[INF] * (N + 1) for _ in range(K + 1)]; back = [[0] * (N + 1) for _ in range(K + 1)]
    best[0][0] = 0
    for k in range(1, K + 1):
        d = segs[k - 1][1] - segs[k - 1][0]
        for j in range(k, N - (K - k) + 1):
            for i in range(k - 1, j):
                if best[k - 1][i] == INF:
                    continue
                c = math.log(d / ((pre[j] - pre[i]) * rate)) ** 2
                if k < K and not brk[j - 1]:
                    c += 0.6
                if best[k - 1][i] + c < best[k][j]:
                    best[k][j] = best[k - 1][i] + c; back[k][j] = i
    times = [0.0] * N; j = N
    for k in range(K, 0, -1):
        i = back[k][j]; a, b = segs[k - 1]
        for q in range(i, j):
            times[q] = a + (b - a) * (pre[q] - pre[i]) / (pre[j] - pre[i])
        j = i
    return times, segs[-1][1]


def from_stt(words, stt):
    a = [norm(w) for w, _ in words]; b = [norm(t) for t, _, _ in stt]
    times = [None] * len(words)
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal" or (tag == "replace" and i2 - i1 == j2 - j1):
            for k in range(i2 - i1):
                times[i1 + k] = stt[j1 + k][1]
        elif tag == "replace":  # different word counts: spread over the heard span
            s, e = stt[j1][1], stt[j2 - 1][2]
            for k in range(i2 - i1):
                times[i1 + k] = s + (e - s) * k / (i2 - i1)
    known = [i for i, t in enumerate(times) if t is not None]
    if not known:
        sys.exit("speech-to-text does not match the script at all; check script.txt")
    for i in range(len(times)):  # interpolate leftovers
        if times[i] is None:
            p = max([k for k in known if k < i], default=None); n = min([k for k in known if k > i], default=None)
            if p is None:
                times[i] = max(0, times[n] - 0.4 * (n - i))
            elif n is None:
                times[i] = times[p] + 0.4 * (i - p)
            else:
                times[i] = times[p] + (times[n] - times[p]) * (i - p) / (n - p)
    ratio = sm.ratio()
    return times, stt[-1][2], ratio


def phrases_for(words, maxw):
    ph, cur = [], []
    for i, (w, li) in enumerate(words):
        if cur and (words[cur[0]][1] != li or len(cur) >= maxw or sum(len(words[k][0]) for k in cur) + len(w) > 26):
            ph.append([cur[0], cur[-1] + 1]); cur = []
        cur.append(i)
        if re.search(r"[,.?!\"”]$", w) and len(cur) >= 2:
            ph.append([cur[0], cur[-1] + 1]); cur = []
    if cur:
        ph.append([cur[0], cur[-1] + 1])
    return ph


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    P = os.path.abspath(sys.argv[1]); rest = sys.argv[2:]
    opt = lambda k, d: rest[rest.index(k) + 1] if k in rest else d
    vo = os.path.join(P, "vo")
    words, nlines = load_script(os.path.join(vo, "script.txt"))
    res = lambda f: f if os.path.isabs(f) or os.path.exists(f) else os.path.join(P, f)
    stt = res(opt("--stt", os.path.join(vo, "stt.json")))
    if os.path.exists(stt):
        sw = load_stt(stt)
        mp_ = opt("--map", None)
        if mp_:
            M = json.load(open(res(mp_)))
            E = M.get("edits") or [[m, M.get("pause", 0)] for m in M.get("inserts", [])]
            f = lambda t: (t - M["trim"] + sum(d for m, d in E if m < t - M["trim"])) / M["tempo"]
            sw = [(w, f(s), f(e)) for w, s, e in sw]
        times, end, ratio = from_stt(words, sw)
        print(f"timings from speech-to-text ({os.path.basename(stt)}), script match {ratio:.2f}"
              + ("  <- LOW: the voice-over may skip or change words, listen and check" if ratio < .8 else ""))
    else:
        audio = res(opt("--audio", os.path.join(vo, "vo.wav")))
        times, end = estimate(words, nlines, audio)
        print("timings estimated from the audio (no stt.json); check the captions on the stills")
    for i in range(1, len(times)):  # keep order
        times[i] = max(times[i], times[i - 1] + 0.08)
    W = [[w, round(t, 2)] for (w, _), t in zip(words, times)]
    ph = phrases_for(words, int(opt("--max-words", 4)))
    T = {"words": W, "phrases": ph}
    ep = os.path.join(vo, "english.txt")
    if os.path.exists(ep):
        en = [l.strip() for l in open(ep, encoding="utf-8").read().splitlines() if l.strip()]
        if len(en) == nlines:
            T["english"] = []
            for li, text in enumerate(en):
                idx = [i for i, (_, l) in enumerate(words) if l == li]
                T["english"].append({"words": [idx[0], idx[-1] + 1], "text": text})
        else:
            print(f"WARNING: english.txt has {len(en)} lines but script.txt has {nlines}; English captions skipped")
    js = "// generated by tools/align.py; edit times by hand if a caption is early/late\nwindow.TIMING=" + json.dumps(T, ensure_ascii=False) + ";\n"
    open(os.path.join(P, "timing.js"), "w", encoding="utf-8").write(js)
    for (w, t) in W:
        print(f"{t:6.2f}  {w}")
    print(f"voice-over speech ends at {end:.2f} s. Suggested STORY.dur = voOffset + {end:.2f} + 2.5 (end card)")
    print("wrote", os.path.join(P, "timing.js"))


if __name__ == "__main__":
    main()
