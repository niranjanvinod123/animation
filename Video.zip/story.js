// പൊതിച്ചോറ് — 15 s test. Every morning Amma packs my lunch with an egg hidden under the rice; her own never had one.
// VO: a slow, warm male narrator (TTS, slowed with audio.py prep --tempo 0.88 --pause 0.25).

const LEAF=[540,1000];   // son's leaf on the counter (top-down)

// a steel ladle seen from above; lift 0..1 raises it toward the camera
function ladleTop(x,y,rot,lift,full){
  const s=1+lift*.6;
  let g=`<ellipse cx="${f1(30+lift*120)}" cy="${f1(40+lift*160)}" rx="${90}" ry="70" fill="#000" opacity="${f1(.25*(1-lift))}" filter="url(#b14)"/>`;
  g+=`<g transform="translate(${f1(x)},${f1(y)}) rotate(${rot}) scale(${f1(s*100)/100})"><rect x="40" y="-14" width="520" height="28" rx="12" fill="url(#steelG)"/><ellipse rx="96" ry="80" fill="url(#steelG)"/><ellipse rx="80" ry="64" fill="#c9ced3"/>${full?riceTop(0,0,58,{seed:4}):''}</g>`;
  return g;
}
// open leaf with food, front view (squashed)
function openLeafFront(x,y,s=1){
  let g=`<ellipse cx="0" cy="22" rx="190" ry="34" fill="#000" opacity=".3" filter="url(#b4)"/><ellipse rx="190" ry="52" fill="url(#leafG)"/><path d="M-180,0 L180,0" stroke="#a8cf86" stroke-width="5" opacity=".7"/>`;
  g+=`<ellipse cx="-20" cy="-14" rx="72" ry="30" fill="url(#riceG)"/><ellipse cx="70" cy="-4" rx="26" ry="12" fill="#b8401c"/><path d="M90,14 Q130,10 160,18" stroke="#3f8f2e" stroke-width="12" stroke-linecap="round"/>`;
  return `<g transform="translate(${x},${y}) scale(${s})">${g}</g>`;
}

// ---------- shots ----------
// S1 hook: top-down, morning sun through the bars; hot rice drops onto the banana leaf
function s1(T,t,{end=false}={}){
  const cam={z:end?lerp(.96,1.0,ramp(T,0,2)):lerp(1.14,1.0,ease(ramp(T,0,2.6))),cx:540,cy:end?760:960};
  let base=counterTop(t)+leafTop(LEAF[0],LEAF[1],720,520,-6);
  const drop=end?1:ramp(T,.35,.75);
  if(drop>0) base+=riceTop(LEAF[0]-10,LEAF[1]-10,170,{seed:2,sc:end?1:back(drop)});
  if(!end){const lift=ease(ramp(T,.75,1.6));
    if(lift<1) base+=ladleTop(lerp(560,900,lift),lerp(900,500,lift),-35+lift*-20,lift,T<.38);}
  let g=layer(cam,1,base);
  g+=layer(cam,1.15,steam(t,LEAF[0],LEAF[1]-60,{h:360,w:160,n:5,op:.45}));
  g+=dust(t,{seed:31,n:30,size:2.4,op:.6,big:5});
  g+=grade('#ffd9a0','#5a2e14',.32);
  if(end) g+=grade('#1a0c04','#1a0c04',.0)+`<rect width="1080" height="1000" fill="url(#endFade)"/><linearGradient id="endFade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1a0c04" stop-opacity="${f1(.55*ramp(T,.2,.8)*100)/100}"/><stop offset="1" stop-color="#1a0c04" stop-opacity="0"/></linearGradient>`;
  return g;
}
// S2: Amma behind the counter ties the parcel (front view, morning light)
function s2(T,t){
  const cam={z:lerp(1.42,1.5,ease(ramp(T,0,2.6))),cx:540,cy:950};
  const wig=Math.sin(t*5)*6, tie=ease(ramp(T,.7,1.7));
  const A={x:540,y:640,s:1,noLower:1,blink:blinkAt(t,[3.4]),lookX:.05,lookY:.85,smile:.45,headTilt:-4,
    hands:{L:[-150+wig,600],R:[150-wig,606]},handAng:{L:60,R:120}};
  let g=layer(cam,.8,`<g filter="url(#b4)">${kitchenBack(t)}</g>`);
  g+=layer(cam,.8,kitchenLight(t));
  g+=layer(cam,1,woman(Object.assign({part:'body'},A))+counterFront(1235)+parcelFront(540,1262,1.05,tie)+woman(Object.assign({part:'hands'},A)));
  g+=layer(cam,1.2,dust(t,{seed:33,n:16,x0:300,x1:1000,y0:300,y1:1200,size:3,op:.5}));
  g+=grade('#ffe2b0','#6a3a1c',.3);
  return g;
}
// S3: top-down close; Amma's hand hides an egg under the rice
function s3(T,t){
  const cam={z:lerp(1.18,1.34,ease(ramp(T,0,4))),cx:540,cy:990};
  const EGG=[548,992];
  let g=counterTop(t)+leafTop(LEAF[0],LEAF[1],720,520,-6)+riceTop(LEAF[0]-10,LEAF[1]-10,170,{seed:2});
  // dig a small hollow (darker) before the egg arrives
  g+=`<ellipse cx="${EGG[0]}" cy="${EGG[1]}" rx="${f1(62*ramp(T,.4,1.2))}" ry="${f1(48*ramp(T,.4,1.2))}" fill="#cfc6b4"/>`;
  // left hand brings the egg in from the top-left, places it, leaves
  const inK=ease(ramp(T,1.1,2.2)), outK=ease(ramp(T,2.45,3.1));
  const eggPos=[lerp(120,EGG[0],inK),lerp(260,EGG[1],inK)];
  const eggS=lerp(1.25,1,inK);
  if(inK>0) g+=eggTop(eggPos[0],eggPos[1],eggS,20);
  if(inK>0&&outK<1){const W=[lerp(eggPos[0]-170,-420,outK),lerp(eggPos[1]-170,-320,outK)]; g+=handTop(W,45)}
  // the right hand pushes rice over the egg
  const cov=ease(ramp(T,2.6,3.4));
  if(cov>0){const c=[lerp(780,EGG[0]+6,cov),lerp(1180,EGG[1]+4,cov)];
    g+=riceTop(c[0],c[1],86,{seed:5,sc:lerp(.7,1,cov)});
    const leave=ease(ramp(T,3.45,3.95)); if(leave<1){const W=[lerp(c[0]+150,1400,leave),lerp(c[1]+180,1700,leave)]; g+=handTop(W,-130)}}
  let out=layer(cam,1,g)+layer(cam,1.15,steam(t,LEAF[0],LEAF[1]-60,{h:300,w:140,n:4,op:.3}));
  out+=dust(t,{seed:34,n:22,size:2.2,op:.5});
  out+=grade('#ffd9a0','#5a2e14',.3);
  return out;
}
// S4: dusk. Amma alone at the counter with her own small packet
function s4(T,t){
  const cam={z:lerp(1.5,1.42,ease(ramp(T,0,2.2))),cx:545,cy:950};
  const A={x:540,y:650,s:1,noLower:1,blink:blinkAt(t,[10.0]),lookX:-.1,lookY:.9,smile:.2,headTilt:6,
    hands:{L:[-170,600],R:[170,604]},handAng:{L:75,R:105}};
  let g=layer(cam,.8,`<g filter="url(#b4)">${kitchenBack(t,{mood:'dusk'})}${lampFront(470,370,t,.9)}</g>`);
  g+=layer(cam,.8,kitchenLight(t,{mood:'dusk'}));
  g+=layer(cam,1,woman(Object.assign({part:'body'},A))+counterFront(1235,{mood:'dusk'})+openLeafFront(540,1275,.95)+woman(Object.assign({part:'hands'},A)));
  g+=grade('#3a4a8a','#1a0f0a',.38,'multiply')+grade('#ffb760','#2a1a40',.22);
  return g;
}
// S5: top-down, her leaf: a little rice, pickle, a chilli. No egg.
function s5(T,t){
  const cam={z:lerp(1.22,1.32,ease(ramp(T,0,2.2))),cx:540,cy:980};
  let g=counterTop(t,{mood:'dusk'})+leafTop(540,990,560,400,8)+riceTop(500,980,105,{seed:9})+pickleTop(650,940,.9)+chilliTop(640,1090,.9,-20);
  const reach=ease(ramp(T,.2,1.2)); const W=[lerp(120,330,reach),lerp(1750,1250,reach)];
  g+=handTop(W,-62);
  let out=layer(cam,1,g)+dust(t,{seed:35,n:14,size:2,op:.35});
  out+=grade('#3a4a8a','#1a0f0a',.3,'multiply')+grade('#ffb760','#2a1a40',.2);
  return out;
}
// S6: end card. Callback to the opening leaf; title fades in
function s6(T,t){return s1(T,t,{end:true})}

window.STORY={
  dur:15.0, voOffset:0.3, dissolve:0.4, captions:'ml',
  shots:[{a:0,b:2.45,f:s1},{a:2.45,b:4.9,f:s2},{a:4.9,b:8.9,f:s3},{a:8.9,b:10.75,f:s4},{a:10.75,b:12.95,f:s5},{a:12.95,b:15.0,f:s6}],
  // words / phrases / english: timing.js (made by tools/align.py from vo/script.txt, vo/english.txt and the STT)
  title:{ml:'പൊതിച്ചോറ്',en:'Pothichoru',meaning:'the packed lunch',handle:'',at:13.15}
};
