"""Render a story project frame by frame (window.renderAt(t)) with headless Chromium, then encode the MP4.

usage:
  render.py PROJECT stills t1 t2 ...        -> PROJECT/work/stills/*.jpg + PROJECT/work/sheet.jpg (contact sheet)
  render.py PROJECT frames [--workers N]    -> PROJECT/work/frames/f_00000.jpg ... (resumes: skips existing frames)
  render.py PROJECT video  [--workers N] [--name NAME]
                                            -> frames (if missing) + PROJECT/out/NAME.mp4 with audio/mix.wav
  render.py PROJECT clean                   -> delete PROJECT/work/frames (do this after any story.js change)

PROJECT is the project folder (index.html + story.js). The engine is served from this skill's engine/ folder.
"""
import functools, http.server, os, sys, threading, shutil
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ENGINE, ffmpeg, run, story_setting, launch_browser

FPS = 30


class Handler(http.server.SimpleHTTPRequestHandler):
    project = "."

    def translate_path(self, path):
        path = path.split("?", 1)[0].split("#", 1)[0]
        if path.startswith("/engine/"):
            return os.path.join(ENGINE, *path[len("/engine/"):].split("/"))
        return os.path.join(self.project, *[p for p in path.split("/") if p])

    def log_message(self, *a):
        pass


def serve(project):
    Handler.project = project
    s = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=s.serve_forever, daemon=True).start()
    return s.server_address[1]


def job(args):
    from playwright.sync_api import sync_playwright
    port, times, outdir, names = args
    errs = []
    with sync_playwright() as p:
        b = launch_browser(p)
        pg = b.new_page(viewport={"width": 1080, "height": 1920}, device_scale_factor=1)
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append(m.text) if m.type == "error" and "404" not in m.text else None)
        pg.goto(f"http://127.0.0.1:{port}/index.html")
        pg.wait_for_function("window.READY === true", timeout=60000)
        for t, n in zip(times, names):
            out = os.path.join(outdir, n)
            if os.path.exists(out):
                continue
            pg.evaluate(f"window.renderAt({t})")
            pg.screenshot(path=out, type="jpeg", quality=93)
        b.close()
    return errs


def ensure_playwright():
    try:
        import playwright  # noqa
    except ImportError:
        import subprocess
        print("installing playwright ...")
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "playwright"], check=True)
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"])


def frames(project, port, workers):
    dur = story_setting(project, "dur")
    if not dur:
        sys.exit("story.js needs STORY.dur")
    fd = os.path.join(project, "work", "frames"); os.makedirs(fd, exist_ok=True)
    N = int(round(dur * FPS))
    todo = [q for q in range(N) if not os.path.exists(f"{fd}/f_{q:05d}.jpg")]
    print(f"{N} frames, {len(todo)} to render with {workers} workers")
    if todo:
        chunks = [todo[i::workers] for i in range(workers) if todo[i::workers]]
        ctx = mp.get_context("fork") if sys.platform != "win32" else mp.get_context("spawn")
        with ProcessPoolExecutor(len(chunks), mp_context=ctx) as ex:
            for e in ex.map(job, [(port, [q / FPS for q in c], fd, [f"f_{q:05d}.jpg" for q in c]) for c in chunks]):
                if e:
                    print("PAGE ERRORS:", e[:3])
    return fd, dur


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    project = os.path.abspath(sys.argv[1]); mode = sys.argv[2]; rest = sys.argv[3:]
    opt = lambda k, d: rest[rest.index(k) + 1] if k in rest else d
    workers = int(opt("--workers", max(2, min(8, (os.cpu_count() or 4) - 1))))
    if mode == "clean":
        shutil.rmtree(os.path.join(project, "work", "frames"), ignore_errors=True); print("frames cleared"); return
    ensure_playwright()
    port = serve(project)
    if mode == "stills":
        ts = [float(x) for x in rest]
        sd = os.path.join(project, "work", "stills"); os.makedirs(sd, exist_ok=True)
        for f in os.listdir(sd):
            os.remove(os.path.join(sd, f))
        names = [f"s_{t:06.2f}.jpg" for t in ts]
        e = job((port, ts, sd, names))
        if e:
            print("PAGE ERRORS:", e[:5])
        from PIL import Image, ImageDraw
        ims = [Image.open(os.path.join(sd, n)) for n in names]
        w, h = 360, 640; cols = min(6, len(ims)); rows = (len(ims) + cols - 1) // cols
        sheet = Image.new("RGB", (w * cols, h * rows), "black")
        for k, (im, t) in enumerate(zip(ims, ts)):
            x, y = (k % cols) * w, (k // cols) * h
            sheet.paste(im.resize((w, h)), (x, y))
            ImageDraw.Draw(sheet).text((x + 8, y + 8), f"{t:.2f}s", fill="yellow")
        sheet.save(os.path.join(project, "work", "sheet.jpg"), quality=88)
        print("stills:", sd, "\nsheet:", os.path.join(project, "work", "sheet.jpg"))
    elif mode in ("frames", "video"):
        fd, dur = frames(project, port, workers)
        if mode == "video":
            name = opt("--name", os.path.basename(project))
            od = os.path.join(project, "out"); os.makedirs(od, exist_ok=True)
            out = os.path.join(od, name + ".mp4")
            mix = os.path.join(project, "audio", "mix.wav")
            cmd = [ffmpeg(), "-y", "-v", "error", "-framerate", str(FPS), "-i", os.path.join(fd, "f_%05d.jpg")]
            if os.path.exists(mix):
                cmd += ["-i", mix, "-c:a", "aac", "-b:a", "192k"]
            else:
                print("WARNING: no audio/mix.wav, the video will be silent (run tools/audio.py mix first)")
            cmd += ["-c:v", "libx264", "-crf", "18", "-preset", "medium", "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-t", f"{dur:.3f}", out]
            run(cmd)
            print("video:", out)
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
