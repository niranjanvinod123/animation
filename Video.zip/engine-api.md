# Engine reference

The frame is an SVG 1080 wide x 1920 tall. `window.renderAt(t)` draws time `t` (seconds); the renderer calls it for
every frame, so everything must be a pure function of time. Load order (template `index.html`): `defs.js`,
`core.js`, `fx.js`, `props.js`, `rig.js`, `sets.js`, then the project's `timing.js` and `story.js`.

## story.js

```js
function s1(T,t){ /* T = time since this shot began (can be slightly <0 or >length during dissolves), t = video time */
  const cam={z:lerp(1.1,1.0,ease(ramp(T,0,3))),cx:540,cy:960};
  let g=layer(cam,.8,`<g filter="url(#b4)">${kitchenBack(t)}</g>`);   // background
  g+=layer(cam,1, /* subject */ '');
  g+=grade('#ffe2b0','#6a3a1c',.3);
  return g;
}
window.STORY={
  dur:20, voOffset:0.3, dissolve:0.4, captions:'ml',              // 'ml' (spoken language only, default) | 'both' | 'en'
  shots:[{a:0,b:3,f:s1},{a:3,b:6,f:s2,cut:true}, ...],           // contiguous, video time; cut:true = hard cut into it
  title:{ml:'കണ്ണട',en:'Kannada',meaning:'the spectacles',handle:'',at:17.6},  // card fades in at `at`
  // words/phrases/english normally come from timing.js; define here to override
};
```

`index.html` sets `--capTop` (top of caption block, px) and `--titleTop` (top of title card).

## core.js — maths, time, camera

| Function | Use |
|---|---|
| `lerp(a,b,k)`, `clamp(x,a=0,b=1)` | basics |
| `ramp(t,a,b)` | 0 before a, 1 after b, linear between — the main animation driver |
| `ease(k)`, `easeOut(k)`, `easeIn(k)`, `back(k)` | easing curves (back = slight overshoot, for pops) |
| `mul(seed)` | seeded random generator: `const r=mul(7); r()` → 0..1 |
| `uid(prefix)` | unique id for inline gradients/clipPaths (reset every frame) |
| `f1(x)` | number → string with 1 decimal (keeps SVG small) |
| `blinkAt(t,[times])` | 0..1 blink amount around the given times; pass as `blink:` to a character |
| `layer(cam,depth,svg)` | camera transform. `cam={z,cx,cy}`: zoom and the world point at frame centre. depth 1 = subject, <1 background (moves less), >1 foreground |

## fx.js — light and atmosphere

| Function | Use |
|---|---|
| `godRays(t,{x,y,w,ang,len,n,op,seed})` | soft light shafts from a window starting at box (x,y,w), angle from vertical |
| `dust(t,{seed,n,x0,x1,y0,y1,col,size,op,big})` | floating specks; `big` adds blurred bokeh discs |
| `steam(t,x,y,{h,w,n,op,seed})` | rising steam wisps |
| `glow(x,y,r,op,id='glowWarm')` | warm radial bloom (lamps, fire, windows) |
| `grade(top,bottom,op,mode='soft-light')` | full-frame colour grade; modes: soft-light, multiply, screen, overlay |
| `rain(t,{seed,n,len,speed,ang,w,op,x0,x1,y0,y1,col,filter})` | rain streaks |
| `ripples(t,cx,cy,rx,ry,{seed,n,period,max,squash,col,op,w})` | rain rings on puddles |

## rig.js — characters (front view, origin = head centre, body hangs below to y≈1130)

**Common options:** `x, y, s` (position/scale), `blink`, `lookX, lookY` (-1..1), `smile` (0..1; >.5 shows teeth),
`headTilt` (deg), `headDY`, `browUp`, `grey` (grey hair), `glasses`, `mustache`, `beard`.

| Function | Options |
|---|---|
| `man(o)` | `shirt, shirtD` (colour, shade), `check` (check-pattern colour), `lower:'mundu'|'trousers'`, `pant`, `swing` (-1..1 arm/feet sway), `wet` (0..1 rain on shoulder), `umb:{tilt,…}` (umbrella in right hand, grip at `MAN_GRIP`) |
| `kid(o)` | school uniform with bag straps; `shirt, shirtD, shorts, badge, legPhase` |
| `woman(o)` | blouse + saree, bun, bindi, earrings, bangles: `blouse, blouseD, saree, sareeD`, `noLower` (hide the skirt, for behind-counter shots), `hands:{L:[x,y],R:[x,y]}` wrist targets in local coords (elbows solve automatically), `handAng:{L,R}` finger direction (deg, 90 = down), `part:'body'|'hands'|'all'` |
| `head(o)` | just a head (`kid`, `woman` flags) — for close-ups or new bodies |
| `handTop(W,ang,{len,col,s,bangle,w})` | forearm + hand seen from above reaching in from outside the frame; W = wrist, ang = finger direction |
| `handHang(W,ang,col,s)` | open hand at wrist W |
| `gripHand(x,y,col,s,flip)` | fist around a vertical handle |
| `limb(A,B,wa,wb,col)` | tapered arm/leg segment with soft edge and shading |
| `sleeve(S,E,{w,len,col,dark,top})` | short sleeve over an upper arm from shoulder S toward elbow E |
| `elbowFor(S,W,l1,l2,side)` | two-bone IK: elbow position for shoulder S and wrist W |
| `bangles(W,E,{cols,w})` | bangles on a forearm |

**Behind a counter:** draw `woman({...A,part:'body'})`, then the counter and the objects on it, then
`woman({...A,part:'hands'})` so the hands rest on top. Same idea for any new body: upper arm → torso → sleeve →
forearm → hand.

**Making a new character:** copy the structure of `man()`/`woman()` (torso path + clipPath + shadeX shading, limbs
behind the torso, sleeves over them, head last) and change the clothes, colours and proportions. Skin colours used:
adult `#9c6643`, woman `#97603f`, child `#a8714b`.

## sets.js — places

| Function | Use |
|---|---|
| `village(t,{walk,warm})` | perspective village path toward the horizon, palms, house, puddles; `walk` (metres) scrolls the ground toward the camera — use it for walking-toward-camera shots |
| `proj(X,Z)` | ground point (X metres sideways, Z metres ahead) → screen [x,y] for `village` |
| `palm(x,y,s,lean,t)`, `fgGrass(t,side)` | coconut palm; blurred foreground grass at the left (1) or right (-1) edge |
| `groundTop(t,{scroll})`, `personTop(x,y,{s,shirt,hair,wet,bag,rot})` | wet ground and people seen from above |
| `kitchenBack(t,{mood})`, `kitchenLight(t,{mood})` | Kerala kitchen wall: barred window, shelf of steel vessels, wood hearth with fire and pot; mood `'morning'|'dusk'` |
| `counterFront(y,{mood})` | counter top edge at y, in front of a character |
| `lampFront(x,y,t,s)` | kerosene lamp with flickering flame and glow |
| `parcelFront(x,y,s,tie)` | tied banana-leaf parcel (tie 0..1) |
| `counterTop(t,{mood,bars})` | wooden table seen from above, sun through window bars |
| `leafTop(cx,cy,w,h,rot)`, `riceTop(cx,cy,r,{seed,sc})`, `eggTop`, `pickleTop`, `chilliTop` | food seen from above |

## props.js — objects and text inserts

| Function | Use |
|---|---|
| `umbrellaFront({x,y,s,tilt,R,L,Hc,t,splash,open})`, `umbrellaTop({cx,cy,R,rot,sx,sy,t,op})` | black umbrella, front / from above |
| `noteCard(x,y,lines,{w,h,rot,size,font,col,paper,ruled,hand,reveal})` | paper note / letter / slip with real text (Malayalam OK); `reveal` 0..1 writes line by line |
| `calendarPage(x,y,{top,day,next,flip,circle,s,brand})` | tear-off wall calendar: `top` = month line, `day` = date shown, `flip` 0..1 lifts that page away to show `next`, `circle` 0..1 draws a red circle round the visible date, `brand` = text on the red header |

## defs.js — shared filters and gradients

Blur filters `b2 b4 b8 b14 b22`, `grain`. Gradients: `skinA skinC skinW cheek hairG shadeX mundu bagG woodG woodTop
steelG leafG riceG eggG glowWarm rayG canopyF canopyTop puddle skyG pathG grassG haze`. Use as `fill="url(#steelG)"`.
Gradients you define inside a shot need `uid()` ids so dissolving shots do not collide.

## Fonts

`Manjari` (Malayalam captions and in-scene text), `Quicksand` (English captions and labels),
`Baloo Chettan 2` (title). Use them in SVG `<text font-family="...">`.
