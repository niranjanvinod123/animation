// StoryAnimator core: deterministic renderAt(t) for code-drawn 2D story reels (1080x1920).
// A project page loads the engine modules, then timing.js (window.TIMING from tools/align.py), then story.js (window.STORY).
const W = 1080, H = 1920;
function mul(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const lerp=(a,b,k)=>a+(b-a)*k;
const ease=k=>k<.5?2*k*k:1-Math.pow(-2*k+2,2)/2;
const easeOut=k=>1-Math.pow(1-k,3);
const back=k=>{const c=1.70158,c3=c+1;return 1+c3*Math.pow(k-1,3)+c*Math.pow(k-1,2)};
const ramp=(t,a,b)=>clamp((t-a)/(b-a));
let UID=0; const uid=p=>p+(UID++);
const f1=x=>(+x).toFixed(1);
function blinkAt(t,ts){for(const b of ts){const d=Math.abs(t-b);if(d<.09)return 1-d/.09}return 0}

// ---------- camera with parallax ----------
// cam = {z, cx, cy}: zoom and the world point at frame centre. depth 1 = subject plane,
// <1 = background (moves/zooms less), >1 = foreground (moves/zooms more).
function layer(cam,depth,svg,extra=''){
  const z=1+(cam.z-1)*depth, cx=540+(cam.cx-540)*depth, cy=960+(cam.cy-960)*depth;
  return `<g transform="translate(540,960) scale(${f1(z*1000)/1000}) translate(${f1(-cx)},${f1(-cy)})" ${extra}>${svg}</g>`;
}
function view(cam,svg){return layer(cam,1,svg)}

// ---------- stage ----------
function buildStage(){
  const defs=window.ENGINE_DEFS||'';
  document.body.innerHTML=`
<svg id="stage" viewBox="0 0 1080 1920" xmlns="http://www.w3.org/2000/svg">
<defs>${defs}</defs>
<g id="world"></g>
<rect id="grainR" width="1080" height="1920" filter="url(#grain)" opacity=".07" style="mix-blend-mode:overlay"/>
</svg>
<div id="vig"></div>
<div id="cap"><div id="capML"></div><div id="capEN"></div></div>
<div id="title"><div class="tml"></div><div class="ten"></div><div class="tmean"></div></div>
<div id="handle"></div>`;
}

// ---------- captions ----------
// STORY.words: [[text, start], ...] in VO time (script spelling). STORY.phrases: [[i0,i1), ...] word index ranges.
// STORY.english: [{words:[i0,i1), text:"..."}] one English line per Malayalam sentence.
// STORY.captions: 'ml' | 'en' | 'both'. Text inside “...” or "..." is shown in italics.
function wordEnd(i){const S=STORY, w=S.words; return i+1<w.length? w[i+1][1] : w[i][1]+0.6}
function italicise(spans){let inQ=false;return spans.map(([w,op])=>{const open=/^["“]/.test(w), close=/["”][.,?!]*$/.test(w);const it=inQ||open;if(open&&!close)inQ=true;if(close)inQ=false;return `<span style="opacity:${op}${it?';font-style:italic':''}">${w}</span>`}).join(' ')}
function captionHTML(t){
  const S=STORY, v=t-(S.voOffset||0), mode=S.captions||'ml';
  if(!S.words||!S.words.length||!S.phrases) return {ml:'',en:''};
  let ml='', en='';
  let pi=-1; S.phrases.forEach(([a],i)=>{if(v>=S.words[a][1]-.08) pi=i});
  const lastEnd=wordEnd(S.words.length-1)+.6;
  if(pi>=0 && v<lastEnd){
    const [a,b]=S.phrases[pi];
    ml=italicise(S.words.slice(a,b).map(([w,s])=>[w,v>=s-.04?1:.32]));
  }
  if(S.english && v<lastEnd){
    let li=-1; S.english.forEach((e,i)=>{if(v>=S.words[e.words[0]][1]-.08) li=i});
    if(li>=0){const e=S.english[li], t0=S.words[e.words[0]][1], t1=wordEnd(e.words[1]-1);
      const ws=e.text.split(' '); en=italicise(ws.map((w,j)=>[w, v>=t0+(t1-t0)*j/ws.length-.04?1:.32]));}
  }
  return {ml: mode==='en'?'':ml, en: mode==='ml'?'':en};
}

// ---------- timeline with dissolves ----------
// STORY.shots: [{a,b,f, cut:false}] contiguous. f(T,t) returns SVG; T = time since the shot began (may be
// slightly negative/positive beyond its range during a dissolve). Default dissolve 0.4 s centred on each change.
function frameSVG(t){
  const S=STORY, sh=S.shots, d=S.dissolve??0.4;
  let i=sh.length-1; for(let k=0;k<sh.length;k++){if(t<sh[k].b){i=k;break}}
  const cur=sh[i];
  // entering dissolve from previous shot
  if(i>0 && !cur.cut && t<cur.a+d/2){const p=sh[i-1], k=(t-(cur.a-d/2))/d;
    return `<g>${p.f(t-p.a,t)}</g><g opacity="${f1(easeIn(k)*1000)/1000}">${cur.f(t-cur.a,t)}</g>`}
  const nx=sh[i+1];
  if(nx && !nx.cut && t>=nx.a-d/2){const k=(t-(nx.a-d/2))/d;
    return `<g>${cur.f(t-cur.a,t)}</g><g opacity="${f1(easeIn(k)*1000)/1000}">${nx.f(t-nx.a,t)}</g>`}
  return cur.f(t-cur.a,t);
}
const easeIn=k=>clamp(k)*clamp(k)*(3-2*clamp(k));

// ---------- title card ----------
// STORY.title = {ml, en, meaning, handle, at, out}
function titleState(t){const T=STORY.title; if(!T) return 0; return ramp(t,T.at,T.at+.6)}

window.renderAt=function(t){
  UID=0;
  document.getElementById('world').innerHTML=frameSVG(t);
  document.querySelector('feTurbulence')?.setAttribute('seed',1+Math.floor(t*30)%7);
  const c=captionHTML(t), k=titleState(t);
  document.getElementById('capML').innerHTML=k>0?'':c.ml;
  document.getElementById('capEN').innerHTML=k>0?'':c.en;
  const T=STORY.title, el=document.getElementById('title');
  if(T){el.style.opacity=k; el.style.transform=`translateY(${f1((1-easeOut(k))*24)}px)`;
    document.getElementById('handle').style.opacity=k;}
};
window.startStory=function(){
  // caption timing can come from timing.js (tools/align.py) instead of being written into story.js
  if(window.TIMING) for(const k of ['words','phrases','english']) if(!STORY[k]&&TIMING[k]) STORY[k]=TIMING[k];
  buildStage();
  const T=STORY.title;
  if(T){const el=document.getElementById('title');
    el.querySelector('.tml').textContent=T.ml||''; el.querySelector('.ten').textContent=T.en||''; el.querySelector('.tmean').textContent=T.meaning||'';
    document.getElementById('handle').textContent=T.handle||'';}
  Promise.all(['700 58px Manjari','600 40px Quicksand','600 120px "Baloo Chettan 2"'].map(f=>document.fonts.load(f)))
    .then(()=>{window.renderAt(0);window.READY=true});
};
