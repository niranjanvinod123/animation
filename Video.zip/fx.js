// ---- rain & ripples ----
// streaks falling across a rectangle; deterministic in t
function rain(t,{seed=1,n=120,len=70,speed=2600,ang=10,w=2,op=.35,x0=-100,x1=1180,y0=-200,y1=2000,col='#e8eef0',filter=''}={}){
  const r=mul(seed), dx=Math.tan(ang*Math.PI/180); let s='';
  const span=y1-y0+len;
  for(let i=0;i<n;i++){
    const x=lerp(x0,x1,r()), ph=r(), sp=speed*(.8+.4*r()), l=len*(.7+.6*r());
    const y=y0+((ph*span+t*sp)%span)-len;
    const xx=x+(y-y0)*dx;
    s+=`<line x1="${f1(xx)}" y1="${f1(y)}" x2="${f1(xx+l*dx)}" y2="${f1(y+l)}"/>`;
  }
  return `<g stroke="${col}" stroke-width="${w}" stroke-linecap="round" opacity="${op}" ${filter?`filter="url(#${filter})"`:''}>${s}</g>`;
}
// ripple rings at random spots inside an ellipse (cx,cy,rx,ry), squash = ry/rx of rings
function ripples(t,cx,cy,rx,ry,{seed=3,n=10,period=.9,max=40,squash=1,col='#eef3f2',op=.7,w=2}={}){
  const r=mul(seed); let s='';
  for(let i=0;i<n;i++){
    const a=r()*Math.PI*2, d=Math.sqrt(r()), px=cx+Math.cos(a)*rx*d*.85, py=cy+Math.sin(a)*ry*d*.85;
    const ph=r(), p=((t/period+ph)%1), m=max*(.6+.6*r());
    const k=easeOut(p);
    s+=`<ellipse cx="${f1(px)}" cy="${f1(py)}" rx="${f1(m*k)}" ry="${f1(m*k*squash)}" fill="none" stroke="${col}" stroke-width="${w}" opacity="${f1((1-p)*op*10)/10}"/>`;
    if(p<.18) s+=`<circle cx="${f1(px)}" cy="${f1(py-3*squash)}" r="${f1(3+2*(1-p/.18))}" fill="${col}" opacity="${f1((1-p/.18)*.8*10)/10}"/>`;
  }
  return s;
}

// ---- light & atmosphere ----
// soft light shafts from a window: origin box (x,y,w), direction angle (deg from vertical), length
function godRays(t,{x,y,w=300,ang=28,len=1300,n=5,op=.5,seed=5}={}){
  const r=mul(seed), a=ang*Math.PI/180, dx=Math.sin(a)*len, dy=Math.cos(a)*len; let g='';
  for(let i=0;i<n;i++){const u=i/(n-1||1), x0=x+u*w, ww=w/n*(.5+r()*.6), fl=.75+.25*Math.sin(t*.9+i*1.7);
    g+=`<path d="M${f1(x0)},${f1(y)} L${f1(x0+ww)},${f1(y)} L${f1(x0+ww*2.2+dx)},${f1(y+dy)} L${f1(x0-ww*.6+dx)},${f1(y+dy)}Z" fill="url(#rayG)" opacity="${f1(op*fl*100)/100}"/>`}
  return `<g filter="url(#b14)" style="mix-blend-mode:screen">${g}</g>`;
}
// floating dust / bokeh specks drifting in light
function dust(t,{seed=9,n=40,x0=0,x1=1080,y0=0,y1=1920,col='#fff4d8',size=3,op=.6,big=0}={}){
  const r=mul(seed); let g='', b='';
  for(let i=0;i<n;i++){const bx=lerp(x0,x1,r()), by=lerp(y0,y1,r()), ph=r()*6.28, sp=.15+r()*.3;
    const x=bx+Math.sin(t*sp+ph)*30+t*6, y=by-((t*12*sp+r()*50)%120)+Math.cos(t*.5+ph)*10, tw=.4+.6*Math.abs(Math.sin(t*1.3+ph));
    g+=`<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(size*(.5+r()))}" fill="${col}" opacity="${f1(op*tw*100)/100}"/>`}
  const r2=mul(seed+1); for(let i=0;i<big;i++){const x=lerp(x0,x1,r2())+Math.sin(t*.3+i)*20, y=lerp(y0,y1,r2());
    b+=`<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(18+r2()*30)}" fill="${col}" opacity="${f1((.08+.1*r2())*100)/100}"/>`}
  return `<g>${g}</g>${big?`<g filter="url(#b8)">${b}</g>`:''}`;
}
// rising steam wisps above (x,y)
function steam(t,x,y,{h=260,w=90,n=4,op=.35,seed=3}={}){
  const r=mul(seed); let g='';
  for(let i=0;i<n;i++){const ph=r(), p=((t*.35+ph)%1), yy=y-p*h, xx=x+(r()-.5)*w*.6+Math.sin(t*1.2+i*2)*w*.25;
    const s=.6+p*1.4;
    g+=`<path d="M${f1(xx)},${f1(yy+40*s)} q${f1(-22*s)},${f1(-30*s)} 0,${f1(-60*s)} q${f1(22*s)},${f1(-30*s)} 0,${f1(-60*s)}" stroke="#ffffff" stroke-width="${f1(14*s)}" fill="none" stroke-linecap="round" opacity="${f1(op*(1-p)*Math.min(1,p*4)*100)/100}"/>`}
  return `<g filter="url(#b8)">${g}</g>`;
}
// warm glow (lamp, hearth, window bloom)
function glow(x,y,r,op=1,id='glowWarm'){return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="url(#${id})" opacity="${op}" style="mix-blend-mode:screen"/>`}
// colour grade over the whole frame (screen coords): top & bottom tint, blend mode
function grade(top,bottom,op=.35,mode='soft-light'){const id=uid('gr');
  return `<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${top}"/><stop offset="1" stop-color="${bottom}"/></linearGradient><rect x="-2000" y="-2000" width="5080" height="5920" fill="url(#${id})" opacity="${op}" style="mix-blend-mode:${mode}"/>`}
