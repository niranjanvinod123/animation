// ---- characters (front view). origin = head centre ----
function eye(cx,cy,s,o,id){
  const w=22*s,h=13*s,bl=clamp(o.blink||0),open=1-bl;
  if(open<.25) return `<path d="M${cx-w},${cy} Q${cx},${cy+5*s} ${cx+w},${cy}" fill="none" stroke="#2a1a14" stroke-width="${3*s}" stroke-linecap="round"/>`;
  const top=cy-h*1.25*open,bot=cy+h*.9*open, cp=uid('e');
  const lx=(o.lookX||0)*9*s, ly=(o.lookY||0)*5*s;
  let g=`<clipPath id="${cp}"><path d="M${cx-w},${cy} Q${cx},${top} ${cx+w},${cy} Q${cx},${bot} ${cx-w},${cy}Z"/></clipPath>`;
  g+=`<path d="M${cx-w},${cy} Q${cx},${top} ${cx+w},${cy} Q${cx},${bot} ${cx-w},${cy}Z" fill="#f4ede4"/>`;
  g+=`<g clip-path="url(#${cp})"><circle cx="${cx+lx}" cy="${cy+ly}" r="${10.5*s}" fill="#4a2c1c"/><circle cx="${cx+lx}" cy="${cy+ly}" r="${7*s}" fill="#2a160d"/><circle cx="${cx+lx}" cy="${cy+ly}" r="${4.2*s}" fill="#0b0605"/>
     <circle cx="${cx+lx+3.5*s}" cy="${cy+ly-4*s}" r="${3*s}" fill="#fff"/><circle cx="${cx+lx-3*s}" cy="${cy+ly+3.5*s}" r="${1.4*s}" fill="#fff" opacity=".7"/>
     <path d="M${cx-w},${cy-h} L${cx+w},${cy-h} L${cx+w},${cy-h*.35*open} Q${cx},${top+3*s} ${cx-w},${cy-h*.35*open}Z" fill="#000" opacity=".12"/></g>`;
  g+=`<path d="M${cx-w-1},${cy+1} Q${cx},${top-1} ${cx+w+1},${cy+1}" fill="none" stroke="#24150f" stroke-width="${3.6*s}" stroke-linecap="round"/>`;
  if(o.lashes){const side=cx<0?-1:1;
    for(const u0 of [.62,.74,.86,.96]){const u=side>0?u0:1-u0, x=(1-u)*(1-u)*(cx-w)+2*u*(1-u)*cx+u*u*(cx+w), y=(1-u)*(1-u)*cy+2*u*(1-u)*(top-1)+u*u*cy;
      g+=`<path d="M${f1(x)},${f1(y)} l${f1(side*6*s)},${f1(-7*s)}" stroke="#1d120d" stroke-width="${2.6*s}" stroke-linecap="round"/>`}}
  return g;
}
function head(o){
  const k=o.kid, wm=o.woman, sk=k?'url(#skinC)':(wm?'url(#skinW)':'url(#skinA)'), s=1, base=k?'#a8714b':'#9c6643', shd=k?'#8a5839':'#7e4f33';
  let g='';
  // ears
  g+=`<ellipse cx="-77" cy="2" rx="13" ry="24" fill="${shd}"/><ellipse cx="77" cy="2" rx="13" ry="24" fill="${shd}"/>`;
  // woman: bun behind the head
  if(wm) g+=`<circle cx="58" cy="-58" r="38" fill="url(#hairG)"/><path d="M40,-80 Q62,-60 46,-30" stroke="#4a3b31" stroke-width="3" fill="none" opacity=".6"/>`;
  // face
  g+=`<path d="M-76,-18 C-80,-112 80,-112 76,-18 C73,52 40,${k?92:100} 0,${k?95:103} C-40,${k?92:100} -73,52 -76,-18Z" fill="${sk}" stroke="#5f3824" stroke-opacity=".6" stroke-width="3"/>`;
  g+=`<ellipse cx="-44" cy="36" rx="26" ry="16" fill="url(#cheek)"/><ellipse cx="44" cy="36" rx="26" ry="16" fill="url(#cheek)"/>`;
  // jaw shade
  g+=`<path d="M-60,50 C-40,${k?90:98} 40,${k?90:98} 60,50 C40,${k?84:90} -40,${k?84:90} -60,50Z" fill="#000" opacity=".08"/>`;
  // beard (narrator)
  if(o.beard) g+=`<path d="M-74,10 C-72,58 -40,104 0,106 C40,104 72,58 74,10 C66,50 44,74 28,72 C14,64 -14,64 -28,72 C-44,74 -66,50 -74,10Z" fill="#1d1511" opacity=".55"/>`;
  // eyes
  const ey=k?2:-4;
  g+=eye(-32,ey,s*(k?1.12:1),Object.assign({lashes:wm},o))+eye(32,ey,s*(k?1.12:1),Object.assign({lashes:wm},o));
  // brows
  const by=ey-(k?30:28)-(o.browUp||0)*6, bw=wm?5:(k?6:8);
  g+=`<path d="M-56,${by+6} Q-36,${by-6} -14,${by+2}" fill="none" stroke="#1f1510" stroke-width="${bw}" stroke-linecap="round"/><path d="M56,${by+6} Q36,${by-6} 14,${by+2}" fill="none" stroke="#1f1510" stroke-width="${bw}" stroke-linecap="round"/>`;
  // nose
  g+=`<path d="M-2,${ey+4} L-13,${ey+38} Q0,${ey+44} 13,${ey+38} L4,${ey+4}Z" fill="${shd}" opacity=".55"/><ellipse cx="-8" cy="${ey+40}" rx="4.5" ry="3" fill="#4d2a1c"/><ellipse cx="8" cy="${ey+40}" rx="4.5" ry="3" fill="#4d2a1c"/><ellipse cx="0" cy="${ey+33}" rx="6" ry="4" fill="#fff" opacity=".18"/>`;
  // mustache
  if(o.mustache) g+=`<path d="M-34,${ey+56} Q-18,${ey+44} 0,${ey+50} Q18,${ey+44} 34,${ey+56} Q18,${ey+58} 0,${ey+55} Q-18,${ey+58} -34,${ey+56}Z" fill="#17100c"/>`;
  // mouth
  const my=ey+(k?60:66), sm=o.smile||0;
  if(sm>.5){g+=`<path d="M-24,${my} Q0,${my+28} 24,${my} Q0,${my+6} -24,${my}Z" fill="#5b2420"/><path d="M-19,${my+2} Q0,${my+9} 19,${my+2} L17,${my+7} Q0,${my+13} -17,${my+7}Z" fill="#f3ece4"/>`}
  else if(wm) g+=`<path d="M-20,${my} Q0,${my-5} 20,${my} Q0,${my+10+sm*10} -20,${my}Z" fill="#8a3b33"/><path d="M-20,${my} Q0,${my+4+sm*10} 20,${my}" fill="none" stroke="#5e2622" stroke-width="2.5"/>`;
  else g+=`<path d="M-22,${my} Q0,${my+8+sm*14} 22,${my}" fill="none" stroke="#5e2c22" stroke-width="4" stroke-linecap="round"/>`;
  // hair
  if(wm){
    const hc=o.grey?'#6f6760':'url(#hairG)';
    g+=`<path d="M-84,14 C-96,-92 -44,-128 0,-126 C44,-128 96,-92 84,14 C80,-20 72,-48 50,-66 C30,-80 10,-84 0,-80 C-10,-84 -30,-80 -50,-66 C-72,-48 -80,-20 -84,14Z" fill="${hc}"/>`;
    g+=`<path d="M0,-124 L0,-82" stroke="#8a6f5c" stroke-width="3" opacity=".7"/><path d="M-56,-100 Q-30,-112 -8,-118 M56,-100 Q30,-112 8,-118 M-70,-70 Q-50,-86 -20,-96 M70,-70 Q50,-86 20,-96" stroke="#4a3b31" stroke-width="2" fill="none" opacity=".55"/>`;
    g+=`<circle cx="0" cy="${ey-34}" r="7" fill="#b3202a"/><circle cx="-78" cy="28" r="6" fill="#e2b44a"/><circle cx="78" cy="28" r="6" fill="#e2b44a"/>`;
  } else if(k){
    g+=`<path d="M-82,-6 C-92,-96 -44,-124 0,-122 C48,-124 94,-94 82,-6 C80,-36 74,-52 62,-60 L54,-44 L46,-62 L34,-48 L24,-66 L10,-50 L-2,-68 L-14,-50 L-28,-66 L-38,-48 L-50,-62 L-60,-44 C-70,-48 -78,-30 -82,-6Z" fill="url(#hairG)"/>`;
  } else {
    g+=`<path d="M-82,-10 C-92,-98 -40,-130 2,-128 C52,-130 94,-94 82,-10 C79,-44 72,-60 58,-70 C22,-84 -26,-80 -58,-66 C-70,-56 -78,-36 -82,-10Z" fill="url(#hairG)"/>`;
    g+=`<path d="M-60,-96 Q-20,-118 30,-112 M-50,-84 Q0,-104 52,-96 M-70,-60 Q-40,-90 10,-92" fill="none" stroke="#4a3b31" stroke-width="2" opacity=".6"/>`;
    g+=`<path d="M-34,-118 Q-30,-96 -36,-78" fill="none" stroke="#5b4a40" stroke-width="2.5" opacity=".7"/>`;
    if(o.grey) g+=`<path d="M70,-62 C78,-50 80,-32 81,-14 M-70,-62 C-78,-50 -80,-32 -81,-14" stroke="#8d8378" stroke-width="5" fill="none" opacity=".8"/>`;
  }
  g+=`<path d="${k?'M-60,-84 Q-10,-118 52,-96':'M-64,-86 Q-12,-124 54,-104'}" stroke="#7a6658" stroke-width="7" stroke-linecap="round" fill="none" opacity=".45" filter="url(#b2)"/>`;
  if(o.glasses){g+=`<rect x="-60" y="${ey-20}" width="50" height="38" rx="12" fill="#cfe3ea" fill-opacity=".12" stroke="#1d1d22" stroke-width="5"/><rect x="10" y="${ey-20}" width="50" height="38" rx="12" fill="#cfe3ea" fill-opacity=".12" stroke="#1d1d22" stroke-width="5"/><path d="M-10,${ey-4} Q0,${ey-10} 10,${ey-4}" stroke="#1d1d22" stroke-width="4" fill="none"/><path d="M-60,${ey-8} L-76,${ey-12} M60,${ey-8} L76,${ey-12}" stroke="#1d1d22" stroke-width="4"/>`}
  return `<g transform="rotate(${o.headTilt||0}) translate(0,${o.headDY||0})">${g}</g>`;
}
const EDGE='#5f3824';
const V=(a,b)=>[b[0]-a[0],b[1]-a[1]];
const nrm=v=>{const l=Math.hypot(v[0],v[1])||1;return [v[0]/l,v[1]/l]};
const P=p=>f1(p[0])+','+f1(p[1]);
// outline only on the outside: draw shapes stroked, then the same shapes filled on top
function outlined(shapes,col,ew=5,eo=.7){return `<g fill="${col}" stroke="${EDGE}" stroke-width="${ew}" stroke-opacity="${eo}" stroke-linejoin="round">${shapes}</g><g fill="${col}">${shapes}</g>`}
function limbShapes(A,B,wa,wb){const d=nrm(V(A,B)),n=[-d[1],d[0]];
  const q=(Q,w,s)=>[Q[0]+n[0]*w/2*s,Q[1]+n[1]*w/2*s];
  return `<path d="M${P(q(A,wa,1))} L${P(q(B,wb,1))} L${P(q(B,wb,-1))} L${P(q(A,wa,-1))}Z"/><circle cx="${f1(A[0])}" cy="${f1(A[1])}" r="${f1(wa/2)}"/><circle cx="${f1(B[0])}" cy="${f1(B[1])}" r="${f1(wb/2)}"/>`}
function limb(A,B,wa,wb,col){
  const d=nrm(V(A,B)),n=[-d[1],d[0]];
  let g=outlined(limbShapes(A,B,wa,wb),col);
  // soft light along one side, shade along the other
    g+=`<path d="M${P([A[0]-n[0]*wa*.3,A[1]-n[1]*wa*.3])} L${P([B[0]-n[0]*wb*.3,B[1]-n[1]*wb*.3])}" stroke="#000" stroke-opacity=".08" stroke-width="${f1(wa*.3)}" stroke-linecap="round"/>`;
  return g;
}
// short sleeve: from the torso's shoulder corner (top) and armpit (pit) out over the upper arm S->E, hem at len
function sleeve(S,E,{w=50,len=150,col,dark,wet=0,top,pit}){
  const d=nrm(V(S,E)); let n=[-d[1],d[0]];
  if(n[0]*Math.sign(S[0])<0) n=[-n[0],-n[1]];          // n points away from the body
  const a2=w/2+13, H=[S[0]+d[0]*len,S[1]+d[1]*len];
  const ho=[H[0]+n[0]*a2,H[1]+n[1]*a2], hi=[H[0]-n[0]*a2,H[1]-n[1]*a2], c=[H[0]+d[0]*12,H[1]+d[1]*12];
  const sh=[S[0]+n[0]*(w/2+8),S[1]+n[1]*(w/2+8)];
  pit=[S[0]-n[0]*(w/2+10)+d[0]*len*.3,S[1]-n[1]*(w/2+10)+d[1]*len*.3];
  const path=`M${P(top)} Q${P([sh[0]+n[0]*4-d[0]*10,sh[1]+n[1]*4-d[1]*10])} ${P(sh)} L${P(ho)} Q${P(c)} ${P(hi)} L${P(pit)}Z`;
  let g=`<path d="${path}" fill="${col}"/>`;
  for(const k of [-.25,.2,.55]){const a=[S[0]+d[0]*len*.35+n[0]*a2*k,S[1]+d[1]*len*.35+n[1]*a2*k], b=[S[0]+d[0]*len*.9+n[0]*a2*k*1.05,S[1]+d[1]*len*.9+n[1]*a2*k*1.05];
    g+=`<path d="M${P(a)} L${P(b)}" stroke="${dark}" stroke-opacity=".5" stroke-width="3" stroke-linecap="round"/>`}
  g+=`<path d="M${P(sh)} L${P(ho)} L${P([H[0]+n[0]*a2*.2,H[1]+n[1]*a2*.2])} L${P([S[0]+n[0]*w*.15,S[1]+n[1]*w*.15])}Z" fill="#000" opacity=".07"/>`;
  if(wet) g+=`<path d="${path}" fill="#1d3550" opacity="${f1(.42*wet*100)/100}"/>`;
  g+=`<path d="M${P(top)} Q${P([sh[0]+n[0]*4-d[0]*10,sh[1]+n[1]*4-d[1]*10])} ${P(sh)} L${P(ho)}" fill="none" stroke="${dark}" stroke-width="3" stroke-opacity=".8"/>`;
  g+=`<path d="M${P(ho)} Q${P(c)} ${P(hi)}" fill="none" stroke="${dark}" stroke-width="5" stroke-linecap="round"/>`;
  return g;
}
// open hand hanging along direction ang (deg, 90 = straight down)
function handHang(W,ang,col,s=1){
  const fx=[-15,-5,5,14], fl=[40,46,45,38];
  let sh=`<rect x="-19" y="-8" width="38" height="40" rx="15"/>`;
  fx.forEach((x,i)=>sh+=`<rect x="${x-4.8}" y="20" width="9.6" height="${fl[i]}" rx="4.8"/>`);
  sh+=`<ellipse cx="-19" cy="14" rx="7.5" ry="17" transform="rotate(22 -19 14)"/>`;
  let g=outlined(sh,col,4.5,.7);
  fx.forEach((x,i)=>g+=`<ellipse cx="${x}" cy="${20+fl[i]-6}" rx="3" ry="3.6" fill="#f3d8c4" opacity=".55"/>`);
  g+=`<path d="M-12,30 L12,30" stroke="#000" stroke-opacity=".12" stroke-width="2"/>`;
  return `<g transform="translate(${P(W)}) rotate(${f1(ang-90)}) scale(${s})">${g}</g>`;
}
// fist wrapped around a vertical handle/strap; thumb on top
function gripHand(x,y,col,s=1,flip=1){
  let sh=`<rect x="-26" y="-22" width="52" height="46" rx="17"/>`;
  sh+=`<ellipse cx="${-10*flip}" cy="-21" rx="17" ry="9" transform="rotate(${-14*flip} ${-10*flip} -21)"/>`;
  let g=outlined(sh,col,4.5,.7);
  [-8,4,15].forEach(yy=>g+=`<path d="M${-2*flip},${yy} L${24*flip},${yy}" stroke="${EDGE}" stroke-opacity=".45" stroke-width="2.5" stroke-linecap="round"/>`);
  [-14,-2,10,21].forEach(yy=>g+=`<ellipse cx="${22*flip}" cy="${yy}" rx="3.2" ry="3.6" fill="#f3d8c4" opacity=".45"/>`);
  return `<g transform="translate(${f1(x)},${f1(y)}) scale(${s})">${g}</g>`;
}

// adult man. o.shirt colour, o.lower 'mundu'|'trousers', o.wet 0..1 (viewer-left shoulder), o.umb {tilt}
const MAN_GRIP=[130,336];
function man(o){
  const sw=o.swing||0;
  const sk='#9c6643', skd='#86563a', sh=o.shirt||'#9fb8c9', shd=o.shirtD||'#7d97aa';
  let g=`<ellipse cx="0" cy="1136" rx="230" ry="34" fill="#1d140d" opacity=".35" filter="url(#b8)"/>`, cp=uid('sh');
  const shirtD=`M-58,128 C-100,140 -138,146 -156,162 C-174,178 -176,200 -174,232 L-166,560 Q0,580 166,560 L174,232 C176,200 174,178 156,162 C138,146 100,140 58,128Z`;
  // neck
  g+=`<path d="M-30,60 L-30,150 L30,150 L30,60Z" fill="${skd}"/><ellipse cx="0" cy="96" rx="34" ry="16" fill="#000" opacity=".14"/>`;
  // lower
  if(o.lower==='trousers'){
    g+=`<path d="M-160,540 L-150,1110 L-28,1110 L-6,640 L6,640 L28,1110 L150,1110 L160,540Z" fill="${o.pant||'#3d4350'}"/><path d="M-90,620 L-92,1100 M90,620 L92,1100" stroke="#000" stroke-opacity=".15" stroke-width="5"/>`;
    g+=`<ellipse cx="-90" cy="${f1(1120+sw*10)}" rx="${f1(64+sw*6)}" ry="22" fill="#231a15"/><ellipse cx="90" cy="${f1(1120-sw*10)}" rx="${f1(64-sw*6)}" ry="22" fill="#231a15"/>`;
  } else {
    g+=`<ellipse cx="-70" cy="${f1(1128+sw*10)}" rx="${f1(50+sw*6)}" ry="18" fill="#3b2418"/><ellipse cx="70" cy="${f1(1128-sw*10)}" rx="${f1(50-sw*6)}" ry="18" fill="#3b2418"/>`;
    g+=`<path d="M-166,540 L166,540 L186,1112 Q0,1128 -186,1112Z" fill="url(#mundu)"/>`;
    g+=`<path d="M40,560 L66,1116" stroke="#c9a54a" stroke-width="7" opacity=".85"/><path d="M-186,1090 Q0,1106 186,1090" stroke="#c9a54a" stroke-width="9" fill="none" opacity=".85"/>`;
    g+=`<path d="M-100,600 L-118,1090 M-30,610 L-36,1100 M110,600 L126,1090" stroke="#000" stroke-opacity=".07" stroke-width="10"/>`;
  }
  // upper arms sit BEHIND the torso; sleeves and forearms are drawn over it later
  const SL=[-150,196], EL=[-180+sw*3,404], WL=[-168+sw*20,588];
  const SR=[150,196], ER=[206,388], WR=MAN_GRIP;
  g+=limb(SL,EL,50,44,sk)+limb(SR,ER,50,44,sk);
  // torso
  g+=`<clipPath id="${cp}"><path d="${shirtD}"/></clipPath>`;
  g+=`<path d="${shirtD}" fill="${sh}" stroke="${shd}" stroke-width="3"/>`;
  g+=`<g clip-path="url(#${cp})">`;
  if(o.check){for(let x=-180;x<200;x+=46)g+=`<rect x="${x}" y="120" width="16" height="470" fill="${o.check}" opacity=".35"/>`;for(let y=140;y<590;y+=46)g+=`<rect x="-190" y="${y}" width="380" height="16" fill="${o.check}" opacity=".3"/>`}
  g+=`<rect x="-180" y="120" width="360" height="470" fill="url(#shadeX)"/>`;
  g+=`<path d="M-60,300 Q-40,420 -64,540 M50,320 Q66,430 44,548 M-120,250 Q-110,330 -126,420" stroke="${shd}" stroke-opacity=".45" stroke-width="4" fill="none"/>`;
  if(o.wet){const wv=o.wet;g+=`<ellipse cx="-150" cy="215" rx="${f1(45+110*wv)}" ry="${f1(50+190*wv)}" fill="#1d3550" opacity="${f1(.2+.4*wv)}" filter="url(#b8)"/>`;
    const r=mul(5);for(let i=0;i<Math.floor(22*wv);i++){g+=`<circle cx="${f1(-170+r()*100)}" cy="${f1(175+r()*220*wv)}" r="${f1(3+r()*4)}" fill="#dfe9f0" opacity=".8"/>`}}
  g+=`</g>`;
  // buttons + collar
  g+=`<path d="M0,190 L0,566" stroke="#000" stroke-opacity=".12" stroke-width="3"/>${[240,320,400,480].map(y=>`<circle cx="7" cy="${y}" r="5" fill="#eee" opacity=".8"/>`).join('')}`;
  g+=`<path d="M-22,140 L0,190 L22,140" fill="${skd}"/>`;
  g+=`<path d="M-58,128 L-22,196 L-4,150Z M58,128 L22,196 L4,150Z" fill="${sh}" stroke="${shd}" stroke-width="3" stroke-linejoin="round"/>`;
  // left arm (viewer left), hanging and swinging; the sleeve sits over the upper arm
  g+=limb(EL,WL,44,36,sk);
  g+=sleeve(SL,EL,{w:50,len:150,col:sh,dark:shd,wet:o.wet||0,top:[-150,158],pit:[-171,300]});
  g+=handHang(WL,Math.atan2(WL[1]-EL[1],WL[0]-EL[0])*180/Math.PI,sk);
  // right arm: upper arm + sleeve, then forearm across to the umbrella grip
  g+=sleeve(SR,ER,{w:50,len:140,col:sh,dark:shd,top:[150,158],pit:[171,290]});
  g+=limb(ER,[WR[0]+20,WR[1]+6],44,38,sk);
  if(o.umb&&!o.umbSkip){g+=umbrellaFront(Object.assign({x:WR[0],y:WR[1]},o.umb));g+=gripHand(WR[0],WR[1],sk);}
  // head
  g+=head(o);
  return `<g transform="translate(${f1(o.x)},${f1(o.y)}) scale(${o.s})">${g}</g>`;
}
// child in school uniform. origin head centre
function kid(o){
  const sk='#a8714b', skd='#8a5839', sh=o.shirt||'#f1f1ee', shd=o.shirtD||'#c9c9c4';
  let g='', cp=uid('ks');
  const lp=o.legPhase||0, l1=Math.sin(lp)*14, l2=-Math.sin(lp)*14;
  g+=`<ellipse cx="0" cy="792" rx="130" ry="24" fill="#1d140d" opacity=".35" filter="url(#b8)"/>`;
  // legs
  g+=limb([-38,560],[-40,748+l1],40,34,sk)+limb([38,560],[40,748+l2],40,34,sk);
  g+=`<rect x="-58" y="${712+l1}" width="38" height="34" rx="4" fill="#f2f2f2"/><rect x="20" y="${712+l2}" width="38" height="34" rx="4" fill="#f2f2f2"/>`;
  g+=`<path d="M-62,${748+l1} q-8,24 22,26 l38,0 q8,-16 -4,-26Z" fill="#131014"/><path d="M62,${748+l2} q8,24 -22,26 l-38,0 q-8,-16 4,-26Z" fill="#131014"/>`;
  // bag behind (only its top shows between the shoulders)
  g+=`<rect x="-92" y="122" width="184" height="290" rx="40" fill="url(#bagG)"/>`;
  // shorts
  g+=`<path d="M-106,420 L106,420 L114,600 L8,600 L0,520 L-8,600 L-114,600Z" fill="${o.shorts||'#2c3c6b'}"/><path d="M-106,436 L106,436" stroke="#000" stroke-opacity=".2" stroke-width="4"/>`;
  // shirt
  const shirtD=`M-42,118 C-70,126 -92,130 -104,142 C-118,156 -120,172 -118,196 L-110,446 Q0,458 110,446 L118,196 C120,172 118,156 104,142 C92,130 70,126 42,118Z`;
  g+=`<path d="M-30,60 L-30,130 L30,130 L30,60Z" fill="${skd}"/><ellipse cx="0" cy="92" rx="30" ry="14" fill="#000" opacity=".14"/>`;
  const KA=[-1,1].map(sgn=>({sgn,S:[sgn*100,166],E:[sgn*120,292],W:[sgn*66,318]}));
  KA.forEach(a=>g+=limb(a.S,a.E,38,34,sk));
  g+=`<clipPath id="${cp}"><path d="${shirtD}"/></clipPath>`;
  g+=`<path d="${shirtD}" fill="${sh}" stroke="${shd}" stroke-width="3"/>`;
  g+=`<g clip-path="url(#${cp})"><rect x="-130" y="110" width="260" height="350" fill="url(#shadeX)"/><path d="M-50,260 Q-40,340 -56,430 M48,270 Q58,350 44,436" stroke="${shd}" stroke-opacity=".6" stroke-width="3" fill="none"/></g>`;
  g+=`<path d="M-42,118 L-14,170 L0,136Z M42,118 L14,170 L0,136Z" fill="${sh}" stroke="${shd}" stroke-width="3" stroke-linejoin="round"/>`;
  if(o.badge) g+=`<rect x="34" y="210" width="40" height="30" rx="4" fill="${o.badge}"/>`;
  // straps
  g+=`<path d="M-74,132 L-62,420 M74,132 L62,420" stroke="#5a1d17" stroke-width="22" stroke-linecap="round"/>`;
  // arms: upper arm + sleeve, forearm in to the strap, fist on the strap
  for(const {sgn,S,E,W} of KA){
    g+=sleeve(S,E,{w:38,len:78,col:sh,dark:shd,top:[sgn*100,138],pit:[sgn*118,232]})+limb(E,[W[0]+sgn*12,W[1]],34,30,sk);
    g+=gripHand(W[0],W[1],sk,.72,sgn);
  }
  g+=`<g transform="scale(.94)">${head(Object.assign({kid:1},o))}</g>`;
  return `<g transform="translate(${f1(o.x)},${f1(o.y)}) scale(${o.s})">${g}</g>`;
}

// ---- two-bone arm: shoulder S to wrist W; elbow bends outward (side = -1 left, +1 right) ----
function elbowFor(S,Wr,l1,l2,side){
  const dx=Wr[0]-S[0], dy=Wr[1]-S[1], d=Math.min(Math.hypot(dx,dy), l1+l2-1), a=Math.atan2(dy,dx);
  const c=Math.acos(clamp((l1*l1+d*d-l2*l2)/(2*l1*d),-1,1));
  // choose the bend that pushes the elbow away from the body
  const e1=[S[0]+l1*Math.cos(a+c),S[1]+l1*Math.sin(a+c)], e2=[S[0]+l1*Math.cos(a-c),S[1]+l1*Math.sin(a-c)];
  return (e1[0]-S[0])*side>(e2[0]-S[0])*side?e1:e2;
}
function bangles(W,E,{cols=['#d9a93a','#2f8a57','#d9a93a'],w=34}={}){
  const d=nrm(V(E,W)), ang=Math.atan2(d[1],d[0])*180/Math.PI; let g='';
  const k=w/34;
  cols.forEach((c,i)=>{const p=[W[0]-d[0]*(26+i*9)*k,W[1]-d[1]*(26+i*9)*k];
    g+=`<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(5*k)}" ry="${f1(w/2+4*k)}" transform="rotate(${f1(ang)} ${f1(p[0])} ${f1(p[1])})" fill="none" stroke="${c}" stroke-width="${f1(5*k)}"/>`});
  return g;
}
// woman (Amma) in blouse + saree. origin = head centre.
// o.hands = {L:[x,y], R:[x,y]} wrist targets (local coords); o.handAng = {L,R} finger direction in degrees.
function woman(o){
  const sk='#97603f', skd='#7f4f33', bl=o.blouse||'#8e2a36', bld=o.blouseD||'#6c1d28', sa=o.saree||'#e8d6b8', sad=o.sareeD||'#c9b28c';
  let g='', cp=uid('ws');
  const SL=[-128,190], SR=[128,190];
  const WL=(o.hands&&o.hands.L)||[-150,560], WR=(o.hands&&o.hands.R)||[150,560];
  const EL=elbowFor(SL,WL,190,175,-1), ER=elbowFor(SR,WR,190,175,1);
  // lower: saree skirt (hidden behind counters in most shots)
  if(!o.noLower) g+=`<path d="M-150,540 L150,540 L176,1110 Q0,1126 -176,1110Z" fill="${sa}"/><path d="M-40,560 L-60,1110 M0,560 L0,1116 M40,560 L58,1110" stroke="${sad}" stroke-width="4" opacity=".8"/>`;
  // upper arms behind the torso
  g+=limb(SL,EL,44,40,sk)+limb(SR,ER,44,40,sk);
  // neck + blouse
  const tD=`M-50,124 C-86,134 -112,140 -130,154 C-148,168 -150,190 -148,220 L-142,560 Q0,574 142,560 L148,220 C150,190 148,168 130,154 C112,140 86,134 50,124Z`;
  g+=`<path d="M-28,60 L-28,150 L28,150 L28,60Z" fill="${skd}"/><ellipse cx="0" cy="92" rx="32" ry="15" fill="#000" opacity=".14"/>`;
  g+=`<clipPath id="${cp}"><path d="${tD}"/></clipPath><path d="${tD}" fill="${bl}"/>`;
  g+=`<g clip-path="url(#${cp})"><path d="M-46,124 Q0,190 46,124 L46,110 L-46,110Z" fill="${skd}"/><rect x="-160" y="110" width="320" height="470" fill="url(#shadeX)"/>`;
  // pallu: saree band from her left shoulder (viewer right) across to the waist
  g+=`<path d="M40,118 L150,150 L150,250 L-40,580 L-150,580 L-150,520Z" fill="${sa}"/>`;
  g+=`<path d="M70,150 L-110,560 M105,170 L-70,575 M135,200 L-30,580" stroke="${sad}" stroke-width="4" opacity=".85"/>`;
  g+=`<path d="M40,118 L-150,520" stroke="#c4973c" stroke-width="7" opacity=".9"/></g>`;
  // gold chain
  g+=`<path d="M-34,128 Q0,196 34,128" fill="none" stroke="#e0b448" stroke-width="3"/>`;
  // sleeves (puffed blouse sleeves), forearms, hands, bangles
  g+=sleeve(SL,EL,{w:44,len:105,col:bl,dark:bld,top:[-126,150]})+sleeve(SR,ER,{w:44,len:105,col:bl,dark:bld,top:[126,150]});
  const ha=o.handAng||{}; let hs='';
  for(const [E,Wr,a] of [[EL,WL,ha.L],[ER,WR,ha.R]]){
    hs+=limb(E,Wr,40,32,sk)+bangles(Wr,E);
    hs+=handHang(Wr,a??Math.atan2(Wr[1]-E[1],Wr[0]-E[0])*180/Math.PI,sk,.95);
  }
  g+=head(Object.assign({woman:1},o));
  // o.part: 'all' (default) | 'body' (no forearms/hands) | 'hands' (only forearms/hands, to draw over a counter)
  const out=o.part==='body'?g:o.part==='hands'?hs:g.replace('<!--HANDS-->','')+hs;
  return `<g transform="translate(${f1(o.x)},${f1(o.y)}) scale(${o.s})">${out}</g>`;
}
// top-down forearm + hand reaching in from outside the frame. W = wrist, ang = finger direction (deg)
function handTop(W,ang,{len=700,col='#97603f',s=1,bangle=true,w=120}={}){
  const a=ang*Math.PI/180, E=[W[0]-Math.cos(a)*len,W[1]-Math.sin(a)*len];
  const sx=Math.cos(a), sy=Math.sin(a); let g=`<path d="M${f1(E[0]+30)},${f1(E[1]+50)} L${f1(W[0]+sx*120+30)},${f1(W[1]+sy*120+50)}" stroke="#000" stroke-width="${w*1.1}" stroke-linecap="round" opacity=".2" filter="url(#b14)"/>`;
  g+=limb(E,W,w*1.1,w*.85,col);
  if(bangle) g+=bangles(W,E,{w:w*.85});
  g+=handHang(W,ang,col,s*w/34);
  return g;
}
