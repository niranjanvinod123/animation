// <TITLE> — one line on what the story is.
// Shots are functions f(T,t): T = seconds since the shot began, t = global time. Each returns SVG for the 1080x1920 frame.
// Every shot: a moving camera (layer + cam), the set, the characters/props, then the light pass (rays/dust/glow/grade).

// S1 hook: the most striking image of the story, up close, from the first frame
function s1(T,t){
  const cam={z:lerp(1.12,1.0,ease(ramp(T,0,3))),cx:540,cy:960};          // slow push-out
  let g=layer(cam,.8,`<g filter="url(#b4)">${kitchenBack(t)}</g>`);       // background, softly blurred
  g+=layer(cam,.8,kitchenLight(t));
  g+=layer(cam,1,counterFront(1235));                                      // subject plane
  g+=layer(cam,1.2,dust(t,{seed:3,n:16,size:3,op:.5}));                    // foreground particles
  g+=grade('#ffe2b0','#6a3a1c',.3);                                        // colour grade (screen space)
  return g;
}
function s2(T,t){ return s1(T,t) }

window.STORY={
  dur:20.0,          // seconds; = voOffset + VO length + ~2.5 s for the end card
  voOffset:0.3,      // the voice starts this many seconds into the video
  dissolve:0.4,      // cross-dissolve length between shots ({cut:true} on a shot = hard cut into it)
  captions:'ml',     // 'ml' = only the language being spoken (default) | 'both' = + translation line | 'en' = translation only
  shots:[{a:0,b:10,f:s1},{a:10,b:20,f:s2}],
  // words / phrases / english come from timing.js (tools/align.py). Define them here only to override.
  title:{ml:'തലക്കെട്ട്',en:'Title',meaning:'what the title means',handle:'',at:17.6}
};
