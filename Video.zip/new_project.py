"""Create a new story project folder.
usage: new_project.py NAME [--dir PARENT]   -> PARENT/NAME/{index.html, story.js, vo/, audio/, out/}"""
import os, shutil, sys
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
a = sys.argv[1:]
if not a: sys.exit(__doc__)
parent = a[a.index("--dir") + 1] if "--dir" in a else os.getcwd()
P = os.path.join(os.path.abspath(parent), a[0])
if os.path.exists(os.path.join(P, "story.js")): sys.exit(f"{P} already has a story.js; not overwriting")
for d in ("vo", "audio", "out", "work"): os.makedirs(os.path.join(P, d), exist_ok=True)
for f in ("index.html", "story.js"): shutil.copy(os.path.join(SKILL, "templates", f), os.path.join(P, f))
for f, txt in (("script.txt", "# one sentence per line, exactly as narrated\n"),):  # vo/english.txt only if the user wants English subtitles
    p = os.path.join(P, "vo", f)
    if not os.path.exists(p): open(p, "w", encoding="utf-8").write("")
print("project:", P)
