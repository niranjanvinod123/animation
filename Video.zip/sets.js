// ---- environments ----
const HZ=760, F=1000, CH=1.5;
function proj(X,Z){return [540+F*X/Z, HZ+F*CH/Z]}
function palm(x,y,s,lean=6,t=0){
  let g=`<path d="M0,0 Q${lean*6},-260 ${lean*14},-520" stroke="#5d5143" stroke-width="22" fill="none" stroke-linecap="round"/>`;
  const tx=lean*14, ty=-520, sway=Math.sin(t*1.3)*3;
  for(let i=0;i<9;i++){const a=(-160+i*40+sway)*Math.PI/180, L=210+((i*37)%50);
    const ex=tx+Math.cos(a)*L, ey=ty+Math.sin(a)*L*.55+70;
    g+=`<path d="M${tx},${ty} Q${f1(tx+Math.cos(a)*L*.5)},${f1(ty+Math.sin(a)*L*.5-60)} ${f1(ex)},${f1(ey)}" stroke="#2f4a33" stroke-width="16" fill="none" stroke-linecap="round"/>`;}
  return `<g transform="translate(${x},${y}) scale(${s})">${g}</g>`;
}
function village(t,{walk=0,warm=0}={}){
  let g=`<rect x="-500" width="2080" height="${HZ+60}" fill="url(#skyG)"/>`;
  // far tree line
  g+=`<g filter="url(#b8)" opacity=".85">`;
  const r=mul(11);
  for(let i=0;i<16;i++){g+=`<ellipse cx="${f1(i*75-40+r()*30)}" cy="${f1(HZ-60+r()*40)}" rx="${f1(70+r()*60)}" ry="${f1(60+r()*50)}" fill="${['#5d7860','#4e6b52','#678266'][i%3]}"/>`}
  g+=`</g>`;
  // house far left
  g+=`<g filter="url(#b4)" opacity=".9"><rect x="40" y="${HZ-150}" width="260" height="150" fill="#d8cfbf"/><path d="M10,${HZ-140} L170,${HZ-240} L330,${HZ-140}Z" fill="#9d5338"/><rect x="90" y="${HZ-110}" width="46" height="70" fill="#5a3d2a"/><rect x="190" y="${HZ-110}" width="70" height="56" fill="#6a4a34"/></g>`;
  // palms (parallax a little)
  g+=`<g filter="url(#b4)" opacity=".9">${palm(820,HZ+20,1,5,t)}${palm(980,HZ+30,.85,-4,t+1)}${palm(380,HZ+10,.7,3,t+2)}</g>`;
  g+=`<rect x="-500" y="${HZ-200}" width="2080" height="1000" fill="url(#haze)"/>`;
  // ground
  g+=`<rect x="-500" y="${HZ}" width="2080" height="${H-HZ+400}" fill="url(#grassG)"/>`;
  const [pl0,]=proj(-1.0,40), [pr0,]=proj(1.0,40), [plb,yb]=proj(-1.0,1.1), [prb,]=proj(1.0,1.1);
  g+=`<path d="M${f1(pl0)},${HZ+38} L${f1(pr0)},${HZ+38} L${f1(prb)},${f1(yb)} L${f1(plb)},${f1(yb)}Z" fill="url(#pathG)"/>`;
  // stones / speckles moving with walk
  const r2=mul(21); let st='';
  for(let i=0;i<160;i++){const X=-1+2*r2(), Z0=1.1+r2()*30, Z=1.1+((Z0-1.1+walk)%30+30)%30;
    const [x,y]=proj(X,Z), rr=Math.max(.6,9/Z);
    st+=`<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(rr*1.6)}" ry="${f1(rr*.7)}" fill="${i%3?'#38312b':'#a59c8f'}" opacity=".55"/>`}
  g+=st;
  // puddles
  const r3=mul(31);
  for(let i=0;i<7;i++){const X=-.6+1.2*r3(), Z0=1.4+i*3.7+r3(), Z=1.1+((Z0-1.1+walk)%26+26)%26, w=.22+.25*r3();
    const [x,y]=proj(X,Z), rx=F*w/Z, ry=rx*CH/Z*.9;
    if(Z<2.3||y>H+50) continue;
    g+=`<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(rx)}" ry="${f1(ry)}" fill="url(#puddle)" opacity=".6"/>`;
    g+=ripples(t,x,y,rx,ry,{seed:40+i,n:Math.min(8,2+Math.floor(rx/40)),period:.8,max:Math.min(60,rx*.25),squash:ry/rx,op:.6,w:Math.max(1,3/Z*2)});
  }
  // grass tufts at path edges
  const r4=mul(51); let tf='';
  for(let i=0;i<70;i++){const side=i%2?1:-1, X=side*(1.0+r4()*.5), Z0=1.1+r4()*28, Z=1.1+((Z0-1.1+walk)%28+28)%28;
    const [x,y]=proj(X,Z), hh=260/Z;
    tf+=`<path d="M${f1(x-hh*.3)},${f1(y)} q${f1(hh*.05)},${f1(-hh*.7)} ${f1(-hh*.25)},${f1(-hh)} M${f1(x)},${f1(y)} q0,${f1(-hh*.8)} ${f1(hh*.15)},${f1(-hh*1.1)} M${f1(x+hh*.3)},${f1(y)} q0,${f1(-hh*.6)} ${f1(hh*.35)},${f1(-hh*.9)}" stroke="#3a5a2c" stroke-width="${f1(Math.max(1.5,14/Z))}" fill="none" stroke-linecap="round"/>`}
  g+=tf;
  if(warm) g+=`<rect width="1080" height="1920" fill="#e7b57a" opacity="${warm}" style="mix-blend-mode:soft-light"/>`;
  return g;
}
// top-down ground
function groundTop(t,{scroll=0}={}){
  let g=`<rect x="-200" y="-400" width="1480" height="2720" fill="#5d554c"/>`;
  g+=`<rect x="-200" y="-400" width="230" height="2720" fill="#47663a"/><rect x="1050" y="-400" width="230" height="2720" fill="#47663a"/>`;
  g+=`<rect x="20" y="-400" width="40" height="2720" fill="#6f6a40" opacity=".5" filter="url(#b8)"/><rect x="1020" y="-400" width="40" height="2720" fill="#6f6a40" opacity=".5" filter="url(#b8)"/>`;
  const r=mul(7); let sp='';
  for(let i=0;i<520;i++){const x=-180+r()*1440, y=(((r()*2720+scroll)%2720)+2720)%2720-400;
    sp+=`<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(1.5+r()*4)}" fill="${i%3?'#3a332d':'#9c9387'}" opacity=".5"/>`}
  g+=sp;
  const r2=mul(9); let tf='';
  for(let i=0;i<120;i++){const left=i%2, x=left?(-150+r2()*190):(1060+r2()*190), y=(((r2()*2720+scroll)%2720)+2720)%2720-400;
    tf+=`<path d="M${f1(x)},${f1(y)} l${f1(-10+r2()*20)},${f1(-24-r2()*20)} M${f1(x)},${f1(y)} l${f1(14)},${f1(-20)} M${f1(x)},${f1(y)} l${f1(-16)},${f1(-14)}" stroke="#2f4a26" stroke-width="5" stroke-linecap="round"/>`}
  g+=tf;
  const pd=[[300,520,150,95],[760,980,120,80],[420,1460,190,110],[820,1760,110,70],[200,140,120,70],[700,300,90,60]];
  pd.forEach(([x,y,rx,ry],i)=>{const yy=((y+scroll)%2720+2720)%2720-400;
    g+=`<path d="M${x-rx},${yy} C${x-rx},${yy-ry*1.2} ${x+rx*.8},${yy-ry*1.1} ${x+rx},${yy-ry*.1} C${x+rx*1.1},${yy+ry} ${x-rx*.6},${yy+ry*1.2} ${x-rx},${yy}Z" fill="url(#puddle)"/>`;
    g+=ripples(t,x,yy,rx,ry,{seed:60+i,n:9,period:.75,max:34,squash:1,op:.65,w:2.2});});
  // drops hitting dry ground
  const r3=mul(13);for(let i=0;i<60;i++){const x=r3()*1080,y=r3()*1920,ph=r3(),p=(t*1.4+ph)%1; if(p>.2)continue;const k=p/.2;
    g+=`<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(2+k*10)}" fill="none" stroke="#e6d6cb" stroke-width="2" opacity="${f1((1-k)*.6*10)/10}"/>`}
  return g;
}
// people from above (shoulders + head top)
function personTop(x,y,{s=1,shirt='#9fb8c9',hair='#1a120d',wet=0,bag=false,rot=0}={}){
  let g=`<ellipse cx="14" cy="20" rx="150" ry="80" fill="#1b100a" opacity=".3" filter="url(#b14)"/>`;
  if(bag) g+=`<rect x="-80" y="-92" width="160" height="66" rx="18" fill="url(#bagG)"/>`;
  g+=`<ellipse rx="140" ry="62" fill="${shirt}"/><ellipse cx="-118" cy="6" rx="34" ry="46" fill="${shirt}"/><ellipse cx="118" cy="6" rx="34" ry="46" fill="${shirt}"/>`;
  if(wet) g+=`<ellipse cx="-110" cy="0" rx="${40+40*wet}" ry="${40+30*wet}" fill="#1d3550" opacity="${f1(.15+.35*wet)}" filter="url(#b8)"/>`;
  g+=`<ellipse cy="-6" rx="62" ry="68" fill="${hair}"/><ellipse cx="-12" cy="-22" rx="26" ry="20" fill="#fff" opacity=".1"/>`;
  return `<g transform="translate(${x},${y}) rotate(${rot}) scale(${s})">${g}</g>`;
}

function fgGrass(t,side=1){
  let g='';const r=mul(side>0?71:72);
  for(let i=0;i<9;i++){const x=(side>0?-40:1120)+side*r()*230, h=300+r()*260, bend=side*(40+r()*90)+Math.sin(t*1.4+i)*8;
    g+=`<path d="M${f1(x-14)},1960 Q${f1(x+bend*.4)},${f1(1960-h*.6)} ${f1(x+bend)},${f1(1960-h)} Q${f1(x+bend*.3+10)},${f1(1960-h*.55)} ${f1(x+16)},1960Z" fill="${i%2?'#2c4426':'#3a5a30'}"/>`}
  return `<g filter="url(#b14)" opacity=".92">${g}</g>`;
}
// ================= KITCHEN (front view, eye level behind a counter) =================
// mood: 'morning' (sun through the window) | 'dusk' (dark blue window, lamp light)
function kitchenBack(t,{mood='morning'}={}){
  const m=mood==='morning';
  let g=`<linearGradient id="kw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${m?'#d9bb8e':'#6d5a4c'}"/><stop offset="1" stop-color="${m?'#b78c5e':'#4a3a30'}"/></linearGradient>`;
  g+=`<rect x="-600" y="-600" width="2280" height="2200" fill="url(#kw)"/>`;
  g+=`<rect x="-600" y="1010" width="2280" height="600" fill="${m?'#8c5a3a':'#3b2a22'}"/><rect x="-600" y="1000" width="2280" height="14" fill="${m?'#6e4329':'#2a1d17'}"/>`;
  // window with wooden bars
  const wx=600, wy=230, ww=380, wh=520;
  g+=`<rect x="${wx-24}" y="${wy-24}" width="${ww+48}" height="${wh+48}" fill="${m?'#4a2f1d':'#24170f'}"/>`;
  if(m){g+=`<rect x="${wx}" y="${wy}" width="${ww}" height="${wh}" fill="#f6f0d6"/><g filter="url(#b8)"><ellipse cx="${wx+90}" cy="${wy+330}" rx="140" ry="190" fill="#9cbf7d"/><ellipse cx="${wx+300}" cy="${wy+380}" rx="150" ry="170" fill="#7fae67"/><ellipse cx="${wx+200}" cy="${wy+120}" rx="190" ry="90" fill="#fffbe8"/></g>`}
  else {g+=`<rect x="${wx}" y="${wy}" width="${ww}" height="${wh}" fill="#1d2a4a"/><circle cx="${wx+280}" cy="${wy+110}" r="26" fill="#e9edf5" opacity=".9"/><g filter="url(#b4)"><ellipse cx="${wx+120}" cy="${wy+430}" rx="160" ry="120" fill="#13203a"/></g>`}
  for(let i=1;i<6;i++){const x=wx+i*ww/6; g+=`<rect x="${x-9}" y="${wy}" width="18" height="${wh}" fill="${m?'#5a3a24':'#2a1b12'}"/><rect x="${x-9}" y="${wy}" width="5" height="${wh}" fill="#fff" opacity=".12"/>`}
  g+=`<rect x="${wx-30}" y="${wy+wh+20}" width="${ww+60}" height="22" fill="${m?'#5a3a24':'#2a1b12'}"/>`;
  // shelf with steel vessels
  g+=`<rect x="40" y="430" width="470" height="18" fill="#5a3a24"/><rect x="40" y="448" width="470" height="8" fill="#000" opacity=".2"/>`;
  [[80,70,96],[170,52,70],[240,90,40],[350,60,86],[430,46,60]].forEach(([x,w,h])=>{g+=`<rect x="${x}" y="${430-h}" width="${w}" height="${h}" rx="${w*.12}" fill="url(#steelG)"/><ellipse cx="${x+w/2}" cy="${430-h}" rx="${w/2}" ry="6" fill="#d9dde0"/>`});
  for(let i=0;i<3;i++){const x=110+i*60; g+=`<line x1="${x}" y1="456" x2="${x}" y2="${560+i*12}" stroke="#7c8288" stroke-width="5"/><ellipse cx="${x}" cy="${578+i*12}" rx="20" ry="16" fill="url(#steelG)"/>`}
  // hearth (adupp) left, with fire glow
  g+=`<path d="M60,1000 L60,860 Q60,820 100,820 L380,820 Q420,820 420,860 L420,1000Z" fill="${m?'#9a5b3a':'#5a3324'}"/><path d="M150,1000 L150,930 Q240,860 330,930 L330,1000Z" fill="#2a120a"/>`;
  const fl=.8+.2*Math.sin(t*9)+.1*Math.sin(t*23);
  g+=`<path d="M180,1000 Q200,${f1(950-fl*20)} 230,${f1(940-fl*30)} Q250,${f1(965-fl*10)} 270,${f1(935-fl*25)} Q290,970 300,1000Z" fill="#ffb347" opacity=".9"/>`;
  g+=glow(240,960,220*fl,m?.6:1);
  g+=`<ellipse cx="240" cy="808" rx="120" ry="26" fill="#2b2b2e"/><path d="M130,806 Q130,740 240,730 Q350,740 350,806Z" fill="#3a3a3e"/>`;
  g+=steam(t,240,730,{h:300,w:110,op:m?.35:.25});
  return g;
}
// light in the kitchen: rays from the window + dust (morning), lamp glow (dusk)
function kitchenLight(t,{mood='morning'}={}){
  if(mood==='morning') return godRays(t,{x:600,y:250,w:380,ang:-32,len:1500,n:6,op:.55})+dust(t,{seed:21,n:46,x0:250,x1:1000,y0:300,y1:1300,size:2.6,op:.7,big:6});
  return glow(470,360,420,.9)+dust(t,{seed:22,n:24,x0:200,x1:800,y0:200,y1:900,size:2,op:.35});
}
// counter in the foreground (front view). top edge at y
function counterFront(y=1170,{mood='morning'}={}){
  const m=mood==='morning';
  return `<path d="M-600,${y} L1680,${y} L1680,${y+120} L-600,${y+120}Z" fill="${m?'#8a5a36':'#5a3a24'}"/><path d="M-600,${y} L1680,${y}" stroke="${m?'#b07a4c':'#7a5230'}" stroke-width="6"/>`+
         `<rect x="-600" y="${y+120}" width="2280" height="900" fill="${m?'#6e3f24':'#3e2416'}"/><rect x="-600" y="${y+120}" width="2280" height="16" fill="#000" opacity=".25"/>`;
}
// kerosene lamp (front view) with flame glow
function lampFront(x,y,t,s=1){
  const fl=1+.06*Math.sin(t*11)+.04*Math.sin(t*27);
  return `<g transform="translate(${x},${y}) scale(${s})"><ellipse cx="0" cy="40" rx="46" ry="12" fill="#a8823a"/><path d="M-34,40 Q-40,0 0,-6 Q40,0 34,40Z" fill="#c99a3e"/><rect x="-12" y="-30" width="24" height="26" fill="#8a6a2a"/>
    <path d="M-22,-30 Q-30,-90 0,-110 Q30,-90 22,-30Z" fill="#fff" opacity=".25"/><path d="M0,${f1(-46-18*fl)} Q10,-50 0,-36 Q-10,-50 0,${f1(-46-18*fl)}Z" fill="#ffd27a"/></g>`+glow(x,y-44*s,170*s*fl,1);
}
// tied banana-leaf parcel (front view, slightly from above)
function parcelFront(x,y,s=1,tie=1){
  let g=`<ellipse cx="0" cy="34" rx="120" ry="20" fill="#000" opacity=".25" filter="url(#b4)"/>`;
  g+=`<path d="M-110,30 Q-120,-30 -80,-46 L80,-46 Q120,-30 110,30 Q0,48 -110,30Z" fill="url(#leafG)"/>`;
  g+=`<path d="M-80,-46 L-20,10 L80,-46" fill="none" stroke="#2d6127" stroke-width="5"/><path d="M-100,0 Q0,16 100,0" stroke="#7bb862" stroke-width="3" fill="none" opacity=".7"/>`;
  if(tie>0) g+=`<path d="M${f1(-112*tie)},${f1(6)} Q0,${f1(22)} ${f1(112*tie)},${f1(6)}" stroke="#f3eee2" stroke-width="5" fill="none"/><path d="M0,-44 L0,${f1(-44+70*tie)}" stroke="#f3eee2" stroke-width="5"/>`;
  return `<g transform="translate(${x},${y}) scale(${s})">${g}</g>`;
}

// ================= TOP-DOWN COUNTER & FOOD =================
function counterTop(t,{mood='morning',bars=true}={}){
  const m=mood==='morning'; let g=`<rect x="-600" y="-600" width="2280" height="3120" fill="url(#woodTop)"/>`;
  for(let i=0;i<14;i++){const y=-600+i*230; g+=`<rect x="-600" y="${y}" width="2280" height="4" fill="#3c2414" opacity=".5"/>`;
    const r=mul(100+i); for(let j=0;j<6;j++){const yy=y+20+r()*190; g+=`<path d="M-600,${f1(yy)} Q${f1(200+r()*400)},${f1(yy+(r()-.5)*30)} 1680,${f1(yy+(r()-.5)*20)}" stroke="#4a2c18" stroke-width="2" fill="none" opacity=".35"/>`}}
  if(m&&bars){ // sunlight patch through the window bars
    let p=`<path d="M-100,-200 L1300,-500 L1500,900 L100,1300Z" fill="#ffe7b0" opacity=".28"/>`;
    for(let i=0;i<6;i++){const x=40+i*250; p+=`<path d="M${x},-400 L${x+70},-400 L${x+330},1500 L${x+260},1500Z" fill="#2a160a" opacity=".22"/>`}
    g+=`<g filter="url(#b22)" style="mix-blend-mode:multiply">${p}</g>`;
  }
  if(!m) g+=`<rect x="-600" y="-600" width="2280" height="3120" fill="#1b1430" opacity=".45"/>`+glow(-60,300,900,.85);
  return g;
}
function leafTop(cx,cy,w,h,rot=0){
  const r=mul(Math.round(cx+cy)); let edge='';
  const pts=[];for(let i=0;i<=24;i++){const a=i/24*Math.PI*2, k=1+(r()-.5)*.03; pts.push([Math.cos(a)*w/2*k*Math.min(1,1.25*Math.abs(Math.cos(a))+.35), Math.sin(a)*h/2*k*Math.min(1,1.25*Math.abs(Math.sin(a))+.35)])}
  edge='M'+pts.map(P).join(' L')+'Z';
  let g=`<path d="${edge}" transform="translate(14,22)" fill="#000" opacity=".3" filter="url(#b14)"/><path d="${edge}" fill="url(#leafG)"/>`;
  g+=`<path d="M${-w/2},0 L${w/2},0" stroke="#a8cf86" stroke-width="10" opacity=".8"/>`;
  for(let x=-w/2+30;x<w/2;x+=26) g+=`<path d="M${x},-6 L${x+14},${-h/2}" stroke="#2f6a2a" stroke-width="2" opacity=".45"/><path d="M${x},6 L${x+14},${h/2}" stroke="#2f6a2a" stroke-width="2" opacity=".45"/>`;
  g+=`<path d="${edge}" fill="#fff" opacity=".06"/>`;
  return `<g transform="translate(${cx},${cy}) rotate(${rot})">${g}</g>`;
}
function riceTop(cx,cy,r,{seed=1,sc=1}={}){
  const R=mul(seed); const pts=[];for(let i=0;i<=28;i++){const a=i/28*Math.PI*2, k=1+(R()-.5)*.16;pts.push([Math.cos(a)*r*k,Math.sin(a)*r*k*.92])}
  let g=`<path d="M${pts.map(P).join(' L')}Z" transform="translate(10,16)" fill="#000" opacity=".22" filter="url(#b8)"/><path d="M${pts.map(P).join(' L')}Z" fill="url(#riceG)"/>`;
  for(let i=0;i<Math.round(r*1.1);i++){const a=R()*6.28, d=Math.sqrt(R())*r*.92; g+=`<ellipse cx="${f1(Math.cos(a)*d)}" cy="${f1(Math.sin(a)*d*.92)}" rx="6" ry="2.6" transform="rotate(${f1(R()*180)} ${f1(Math.cos(a)*d)} ${f1(Math.sin(a)*d*.92)})" fill="${R()<.5?'#ffffff':'#d9d1c1'}" opacity=".9"/>`}
  return `<g transform="translate(${cx},${cy}) scale(${sc})">${g}</g>`;
}
function eggTop(cx,cy,s=1,rot=20){
  return `<g transform="translate(${cx},${cy}) rotate(${rot}) scale(${s})"><ellipse cx="8" cy="10" rx="50" ry="38" fill="#000" opacity=".22" filter="url(#b4)"/><ellipse rx="50" ry="38" fill="url(#eggG)"/><ellipse cx="-16" cy="-14" rx="14" ry="8" fill="#fff" opacity=".9"/></g>`;
}
function pickleTop(cx,cy,s=1){
  const R=mul(7); let g=`<ellipse rx="46" ry="34" fill="#9a2a14"/><ellipse rx="40" ry="28" fill="#b8401c"/>`;
  for(let i=0;i<6;i++) g+=`<rect x="${f1((R()-.5)*50)}" y="${f1((R()-.5)*34)}" width="14" height="12" rx="3" fill="#e7c36a" opacity=".85" transform="rotate(${f1(R()*60)})"/>`;
  g+=`<ellipse cx="-12" cy="-10" rx="12" ry="6" fill="#fff" opacity=".35"/>`;
  return `<g transform="translate(${cx},${cy}) scale(${s})">${g}</g>`;
}
function chilliTop(cx,cy,s=1,rot=0){
  return `<g transform="translate(${cx},${cy}) rotate(${rot}) scale(${s})"><path d="M-70,0 Q-10,-22 60,-6 Q70,0 60,6 Q-10,18 -70,0Z" fill="#3f8f2e"/><path d="M60,-2 L84,-14" stroke="#2f5a22" stroke-width="7" stroke-linecap="round"/><path d="M-50,-4 Q0,-14 50,-6" stroke="#9fd07a" stroke-width="3" fill="none" opacity=".7"/></g>`;
}
