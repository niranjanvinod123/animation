// ---- umbrella ----
// front view. origin = handle grip (hand). tilt in degrees (positive = canopy leans right)
function umbrellaFront({x,y,s=1,tilt=0,R=430,L=720,Hc=210,t=0,splash=true,open=1}){
  const top=-L, rim=-L+Hc*open, n=6, Rw=R*(.25+.75*open);
  let tips=[]; for(let i=0;i<=n;i++){tips.push(-Rw+i*2*Rw/n)}
  let g='';
  // shaft + handle
  g+=`<line x1="0" y1="${top}" x2="0" y2="40" stroke="#2a2a2e" stroke-width="9"/>`;
  g+=`<path d="M0,30 L0,70 Q0,118 -38,118 Q-68,118 -68,88" fill="none" stroke="url(#woodG)" stroke-width="18" stroke-linecap="round"/>`;
  // panels
  for(let i=0;i<n;i++){
    const a=tips[i], b=tips[i+1], m=(a+b)/2;
    const shade=['#101013','#1d1d21','#2a2a30','#25252a','#18181b','#0c0c0e'][i];
    g+=`<path d="M0,${top} Q${f1(a*.82)},${f1(top+Hc*.28)} ${f1(a)},${f1(rim)} Q${f1(m)},${f1(rim-26*open)} ${f1(b)},${f1(rim)} Q${f1(b*.82)},${f1(top+Hc*.28)} 0,${top}Z" fill="${shade}"/>`;
  }
  // ribs
  for(let i=1;i<n;i++){const a=tips[i];g+=`<path d="M0,${top} Q${f1(a*.82)},${f1(top+Hc*.28)} ${f1(a)},${f1(rim)}" fill="none" stroke="#3b3b42" stroke-width="2.5" opacity=".8"/>`}
  // sheen
  g+=`<path d="M${f1(-Rw*.12)},${top+18} Q${f1(-Rw*.55)},${f1(top+Hc*.3)} ${f1(-Rw*.78)},${f1(rim-30)}" fill="none" stroke="#9aa0aa" stroke-width="16" opacity=".22" stroke-linecap="round" filter="url(#b4)"/>`;
  // tips + ferrule
  tips.forEach(a=>g+=`<circle cx="${f1(a)}" cy="${f1(rim+2)}" r="5" fill="#b9bcc2"/>`);
  g+=`<rect x="-6" y="${top-46}" width="12" height="50" rx="5" fill="#8d9097"/>`;
  // rain splashes on canopy
  if(splash){const r=mul(77);for(let i=0;i<26;i++){const u=r()*2-1, ph=r(), p=((t*1.6+ph)%1);if(p>.35)continue;
      const xx=u*Rw*.92, yy=top+Hc*.95*Math.pow(Math.abs(u),1.7)*open-4, k=p/.35;
      g+=`<path d="M${f1(xx-10*k-3)},${f1(yy-2)} q${f1(4+6*k)},${f1(-10-10*k)} ${f1(10+12*k)},0" fill="none" stroke="#dfe6ea" stroke-width="2.4" opacity="${f1((1-k)*.9*10)/10}"/>`}}
  return `<g transform="translate(${f1(x)},${f1(y)}) scale(${s}) rotate(${tilt})">${g}</g>`;
}
// top view (from above) at center cx,cy radius R. squash for tilt
function umbrellaTop({cx,cy,R=330,rot=0,sx=1,sy=1,t=0,op=1}){
  const n=8; let g=`<ellipse cx="18" cy="34" rx="${R*1.02}" ry="${R*1.0}" fill="#1b120c" opacity=".35" filter="url(#b22)"/>`;
  const pts=[];for(let i=0;i<n;i++){const a=i/n*Math.PI*2;pts.push([Math.cos(a)*R,Math.sin(a)*R])}
  for(let i=0;i<n;i++){const [ax,ay]=pts[i],[bx,by]=pts[(i+1)%n];const mx=(ax+bx)/2*.9,my=(ay+by)/2*.9;
    g+=`<path d="M0,0 L${f1(ax)},${f1(ay)} Q${f1(mx)},${f1(my)} ${f1(bx)},${f1(by)}Z" fill="${i%2?'#141417':'#1f1f23'}"/>`}
  g+=`<circle r="${R}" fill="url(#canopyTop)" opacity=".75" style="mix-blend-mode:screen"/>`;
  for(let i=0;i<n;i++){const [ax,ay]=pts[i];g+=`<line x1="0" y1="0" x2="${f1(ax)}" y2="${f1(ay)}" stroke="#45454d" stroke-width="3"/><circle cx="${f1(ax)}" cy="${f1(ay)}" r="6" fill="#b6b9bf"/>`}
  // re-cut the scalloped edge (cover outside) by drawing nothing; add rim highlight
  g+=`<circle r="14" fill="#9a9da4"/><circle r="6" fill="#e3e5e8"/>`;
  // drops landing on canopy: tiny rings
  g+=ripples(t,0,0,R*.9,R*.9,{seed:91,n:22,period:.7,max:18,col:'#c9ced6',op:.55,w:2});
  return `<g transform="translate(${f1(cx)},${f1(cy)}) rotate(${rot}) scale(${sx},${sy})" opacity="${op}">${g}</g>`;
}

// ---- text inserts (notes, slips, labels). Text is real SVG text, so Malayalam renders with the bundled fonts ----
// paper note / slip / letter. lines = ['line 1','line 2']; hand=true uses a looser handwritten feel (slight rotation per line)
function noteCard(x,y,lines,{w=520,h=null,rot=-4,size=46,font='Manjari',col='#2b2420',paper='#f6efe0',lineGap=1.5,ruled=true,hand=true,reveal=1}={}){
  const H=h||Math.max(220,lines.length*size*lineGap+120);
  let g=`<rect x="${-w/2+14}" y="${-H/2+22}" width="${w}" height="${H}" rx="8" fill="#000" opacity=".28" filter="url(#b8)"/><rect x="${-w/2}" y="${-H/2}" width="${w}" height="${H}" rx="8" fill="${paper}"/>`;
  if(ruled) for(let yy=-H/2+60+size;yy<H/2-20;yy+=size*lineGap) g+=`<line x1="${-w/2+30}" y1="${yy+8}" x2="${w/2-30}" y2="${yy+8}" stroke="#9fb4c8" stroke-width="2" opacity=".5"/>`;
  const shown=Math.ceil(lines.length*clamp(reveal));
  lines.slice(0,shown).forEach((l,i)=>{const yy=-H/2+60+size+i*size*lineGap;
    g+=`<text x="${-w/2+44}" y="${yy}" font-family="${font}" font-weight="700" font-size="${size}" fill="${col}" transform="rotate(${hand?f1((i%2?.6:-.5)):0} ${-w/2+44} ${yy})">${l}</text>`});
  g+=`<rect x="${-w/2}" y="${-H/2}" width="${w}" height="${H}" rx="8" fill="url(#shadeX)" opacity=".5"/>`;
  return `<g transform="translate(${f1(x)},${f1(y)}) rotate(${rot})">${g}</g>`;
}
// wall calendar page (front view). flip 0..1 lifts the top page (`day`) up and away to show `next`
function calendarPage(x,y,{top='',day='',next='',flip=0,circle=0,s=1,brand=''}={}){
  const page=d=>`<rect x="-170" y="-40" width="340" height="360" fill="#fbf7ee"/><rect x="-170" y="-40" width="340" height="360" fill="url(#shadeX)" opacity=".35"/><text x="0" y="40" text-anchor="middle" font-family="Manjari" font-weight="700" font-size="44" fill="#2b2420">${top}</text><text x="0" y="250" text-anchor="middle" font-family="Quicksand" font-weight="700" font-size="190" fill="#b3202a">${d}</text>`;
  let g=`<rect x="-176" y="-130" width="352" height="460" rx="6" fill="#000" opacity=".25" filter="url(#b8)"/>`;
  g+=page(next||day);
  if(circle>0) g+=`<ellipse cx="0" cy="186" rx="118" ry="96" fill="none" stroke="#c0392b" stroke-width="9" stroke-linecap="round" stroke-dasharray="${f1(680*circle)} 800" transform="rotate(-80 0 186)"/>`;
  const k=easeIn(clamp(flip));
  if(k<1) g+=`<g transform="translate(0,-40) scale(1,${f1((1-k)*1000)/1000}) translate(0,40)">${page(day)}<rect x="-170" y="-40" width="340" height="360" fill="#000" opacity="${f1(k*.3*100)/100}"/></g>`;
  g+=`<rect x="-176" y="-136" width="352" height="100" fill="#b3202a"/><rect x="-176" y="-40" width="352" height="6" fill="#000" opacity=".2"/><text x="0" y="-72" text-anchor="middle" font-family="Manjari" font-weight="700" font-size="40" fill="#fff">${brand}</text><circle cx="0" cy="-150" r="10" fill="#555"/>`;
  return `<g transform="translate(${f1(x)},${f1(y)}) scale(${s})">${g}</g>`;
}
