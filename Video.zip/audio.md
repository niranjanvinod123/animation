# Audio

Target: one clean voice-over take, a soft music bed that never drops to silence, one or two quiet sound effects,
final loudness about -15 LUFS.

## Route A — the user uploaded an audio file

1. Copy it into the project: `vo/raw.<ext>`.
2. Get the words with timestamps (best first):
   - **ElevenLabs connector:** `creative_transcribe_audio` with `model_id:"eleven_scribe_v1"` and no `connect_from`
     shows a picker; ask the user to pick the same audio file there. Or, if the file is reachable by a direct link,
     `creative_attach_reference_file` and then `creative_transcribe_audio` with `connect_from:[that node]`.
     When the run finishes, `creative_get_flow_run_status` returns `transcripts[0].words` (each word with
     `start`/`end`) and `words_download_url`. Save that list as `vo/stt.json`. If the transcript only arrives in the
     widget, it may appear on the user's next message — finish other work (script.txt, shot plan) meanwhile.
   - **API key:** `python3 SKILL/tools/stt_api.py vo/raw.mp3 vo/stt.json --lang mal` (`--lang eng` etc. for others).
   - **Neither:** ask the user to paste the exact script; `align.py` will estimate timings from the audio.
3. Write `vo/script.txt` from the transcript: one sentence per line, corrected spelling (speech-to-text often splits
   or misspells Malayalam words; the aligner matches them anyway). Write `vo/english.txt` line for line only if the user wants English subtitles too.
4. `python3 SKILL/tools/audio.py prep vo/raw.mp3 vo/vo.wav` (no tempo change for a human voice), then
   `python3 SKILL/tools/align.py <project> --map vo/vo.wav.timemap.json` (the map accounts for the trimmed start).

## Route B — make the voice-over with the ElevenLabs connector

1. Script approved by the user (see story-writing.md).
2. `creative_list_voices` → choose a slow, warm, mature narrator that speaks the language well (for Malayalam a
   male storyteller voice by default unless the story is told by a woman or child). Don't ask; the result has a
   voice switcher the user can use.
3. `creative_create_flow`, then `creative_generate_speech` with that `flow_id`, `model_id:"eleven_v4"`,
   `generations_count:1` (or 2 if the user wants to choose) and the **whole script as one prompt**: sentences on
   separate lines, a blank line between sentences, `...` for breaths inside a sentence.
4. When the run completes, get the audio from `creative_get_flow_run_status` (output URL) and download it to
   `vo/raw.mp3` (`curl -L -o vo/raw.mp3 "<url>"`). If the sandbox cannot reach the URL, ask the user to download the
   take from the player and attach it to the chat.
5. Transcribe that same take: `creative_transcribe_audio` with `connect_from:[<the TTS node_id>]` on the same flow →
   save the words as `vo/stt.json`.
6. Check the take: `align.py` prints "script match". Below ~0.8, or if any line is missing or garbled, generate the
   whole script again (ask before spending more credits). **Never stitch sentences from different takes** — the
   voice changes between takes and the joins are audible.
7. TTS reads faster than a storyteller. Slow it and open the pauses:
   `python3 SKILL/tools/audio.py prep vo/raw.mp3 vo/vo.wav --tempo 0.88 --pause 0.25`
   (it prints every pause with a number; shorten a dead gap after a `...` with `--gap N=0.7`)
   then `python3 SKILL/tools/align.py <project> --map vo/vo.wav.timemap.json`.
   (eleven_v4 ignores speed settings, so slowing is done here, with the pitch kept.)

## Route C — ElevenLabs API key (env `ELEVENLABS_API_KEY`)

```bash
python3 SKILL/tools/tts_api.py <voice_id> vo/script.txt vo/raw.mp3
python3 SKILL/tools/stt_api.py vo/raw.mp3 vo/stt.json --lang mal
```
Then step 7 of route B. Never print, log or save the key anywhere.

## Music

- The user's own track (royalty-free) is best: `audio.py mix <project> --music path/to/track.mp3`.
- No track: `python3 SKILL/tools/audio.py music audio/bed.wav <dur> --mood warm|night|bright` makes an original,
  quiet bed (drone, soft pad, slow plucked pentatonic notes, room reverb).
- With the full ElevenLabs connector or API (music generation): ask for ~dur+2 s of "soft, slow, warm Indian
  acoustic underscore, veena and piano, gentle tanpura drone, no percussion, no vocals, emotional, nostalgic".
- The bed sits ~20 dB under the voice and ducks a little more while the voice speaks (`--music-db`, default -21).

## Sound effects

Only on the key action (rice dropping, a door, a bicycle bell, rain starting, a page turn). Connector:
`creative_generate_in_flow` with `node_type:"sfx"`, `model_id:"eleven_text_to_sound_v2"`, a short prompt
("soft thud of cooked rice dropping on a banana leaf, close, quiet kitchen"). Download, then
`--sfx audio/x.mp3@<video time>@<dB>` (around -8 to -14 dB).

## Mix

```bash
python3 SKILL/tools/audio.py mix <project> --music audio/bed.wav --sfx audio/drop.mp3@0.45@-10
```
→ `audio/mix.wav`, exactly `STORY.dur` long, VO starting at `STORY.voOffset`, normalised to -15 LUFS.
Re-run the mix whenever `dur`, `voOffset` or the VO changes.
