"""Optional: text-to-speech through the ElevenLabs API (needs ELEVENLABS_API_KEY in the env).
usage: tts_api.py VOICE_ID script.txt OUT.mp3 [--model eleven_v4]
Reads the whole script as ONE take (never stitch sentences from different takes). Lines are joined with
a pause marker so each sentence ends with a breath. Not needed when the ElevenLabs connector is available."""
import json, os, sys, urllib.request
a = sys.argv[1:]
if len(a) < 3: sys.exit(__doc__)
K = os.environ.get("ELEVENLABS_API_KEY") or sys.exit("set ELEVENLABS_API_KEY")
model = a[a.index("--model") + 1] if "--model" in a else "eleven_v4"
lines = [l.strip() for l in open(a[1], encoding="utf-8").read().splitlines() if l.strip() and not l.startswith("#")]
text = "\n\n".join(lines)
body = json.dumps({"text": text, "model_id": model}).encode()
req = urllib.request.Request(f"https://api.elevenlabs.io/v1/text-to-speech/{a[0]}?output_format=mp3_44100_192", data=body,
      headers={"xi-api-key": K, "Content-Type": "application/json", "User-Agent": "story-reel-animator"})
open(a[2], "wb").write(urllib.request.urlopen(req, timeout=300).read())
print("wrote", a[2])
