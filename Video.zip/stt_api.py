"""Optional: speech-to-text with word timestamps through the ElevenLabs API (needs ELEVENLABS_API_KEY in the env).
usage: stt_api.py AUDIO OUT.json [--lang mal]
Not needed when the ElevenLabs connector is available (creative_transcribe_audio gives the same word list)."""
import json, os, sys, uuid, urllib.request
a = sys.argv[1:]
if len(a) < 2: sys.exit(__doc__)
K = os.environ.get("ELEVENLABS_API_KEY") or sys.exit("set ELEVENLABS_API_KEY")
lang = a[a.index("--lang") + 1] if "--lang" in a else "mal"
b = uuid.uuid4().hex; parts = []
for k, v in [("model_id", "scribe_v2"), ("language_code", lang), ("timestamps_granularity", "word")]:
    parts.append(f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
parts.append(f'--{b}\r\nContent-Disposition: form-data; name="file"; filename="a.wav"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode() + open(a[0], "rb").read() + b"\r\n")
parts.append(f"--{b}--\r\n".encode())
req = urllib.request.Request("https://api.elevenlabs.io/v1/speech-to-text", data=b"".join(parts),
      headers={"xi-api-key": K, "Content-Type": f"multipart/form-data; boundary={b}", "User-Agent": "story-reel-animator"})
d = json.loads(urllib.request.urlopen(req, timeout=300).read())
ws = [w for w in d["words"] if w.get("type") == "word"]
json.dump(ws, open(a[1], "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print(d["text"]); print(len(ws), "words ->", a[1])
